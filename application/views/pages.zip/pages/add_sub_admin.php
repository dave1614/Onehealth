  <style>
    #select-sub-admin-card{
      min-height: 350px;
    }
    #select-sub-admin-form{
      margin-top: 30px;
    }
  </style>

      <!-- End Navbar -->
      <script>
        function addUserAsSubAdmin(elem,evt,user_id) {
          evt.preventDefault();
          $(".spinner-overlay").show();
          $.ajax({
            url : "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/add_sub_admin'); ?>",
            type : "POST",
            responseType : "text",
            dataType : "text",
            data : "add_sub_admin=true&user_id="+user_id,
            success : function(response){
              $(".spinner-overlay").hide();
              console.log(response);
              if(response == 1){
                document.location.assign("<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/admin'); ?>")
              }
            },
            error :function(){
              $(".spinner-overlay").hide();
              $.notify({
              message:"Something Went Wrong"
              },{
                type : "danger"  
              });
            }
          })
      
        }

        function goDefault() {
          $("#choose-action-card").show("slow");
          $("#add-new-sub-admin-card").hide("slow");
          $("#select-sub-admin-card").hide("slow");
          $(".go-back").remove();
        }
      </script>
      <?php
        if(is_array($curr_health_facility_arr)){
          foreach($curr_health_facility_arr as $row){
            $health_facility_name = $row->name;
            $health_facility_logo = $row->logo;
            $health_facility_structure = $row->facility_structure;
            $health_facility_email = $row->email;
            $health_facility_phone = $row->phone;
            $health_facility_country = $row->country;
            $health_facility_state = $row->state;
            $health_facility_address = $row->address;
            $health_facility_table_name = $row->table_name;
            $health_facility_date = $row->date;
            $health_facility_time = $row->time;
            $health_facility_slug = $row->slug;
          }
        }
      ?>
      <div class="spinner-overlay" style="display: none;">
        <div class="spinner-well">
          <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
        </div>
      </div>
      <div class="content">
        <div class="container-fluid">
          <h2 class="text-center"><?php echo $health_facility_name; ?></h2>
          <?php
            $depts_arr = $this->onehealth_model->getDeptById($dept_id);
            if(is_array($depts_arr)){
                foreach($depts_arr as $dept){
                  $dept_name = $dept->name;
                  $dept_slug = $dept->slug;        
                } 
              $sub_dept_info = $this->onehealth_model->getSubDeptBySlug($third_addition);
              if(is_array($sub_dept_info)){
                foreach($sub_dept_info as $sub_dept){
                  $sub_dept_id = $sub_dept->id;
                  $sub_dept_name = $sub_dept->name;
                }
              }
            } 
          ?>
          <?php if($this->onehealth_model->checkIfUserIsATopAdmin($health_facility_table_name,$user_name)){ ?>
          <span style="text-transform: capitalize; font-size: 13px;" ><a class="text-primary" href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/admin') ?>">Home</a>&nbsp;&nbsp; > >  </span>
          <span style="text-transform: capitalize; font-size: 13px;" ><a class="text-primary" href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/admin') ?>"><?php echo $dept_name; ?></a>&nbsp;&nbsp; > >  <?php echo $sub_dept_name; ?> </span>
          <?php  } ?>
          <h3 style="text-transform: capitalize;" class="text-center"><?php echo $sub_dept_name; ?></h3>
           <h3>Welcome <?php echo $user_name; ?></h3>
          <?php
            $sub_dept_info = $this->onehealth_model->getSubDeptBySlug($third_addition);
            if(is_array($sub_dept_info)){
              foreach($sub_dept_info as $sub_dept){
                $sub_dept_id = $sub_dept->id;
                $sub_dept_name = $sub_dept->name;
                $sub_dept_slug = $sub_dept->slug;
                 if($this->onehealth_model->getHealthFacilityTableByDeptAndPosition($health_facility_table_name,$dept_slug,$sub_dept_slug) !== false){
                  $health_facility_table_info = $this->onehealth_model->getHealthFacilityTableByDeptAndPosition($health_facility_table_name,$dept_slug,$sub_dept_slug);
                  if(is_array($health_facility_table_info)){
                    foreach($health_facility_table_info as $user){
                      $user_name = $user->user_name;
                      $user_name_slug = url_title($user_name);
                    }
                  }
                }
              }
            }
          ?>
          
          <?php if($no_admin == false){ ?>
          <h4>Admin: <a href="<?php echo site_url('onehealth/'.$user_name_slug) ?>"><?php echo $user_name; ?></a></h4>
          <?php } ?>  
          <div class="row">
            <div class="col-sm-8 col-center">
              <div class="card" id="choose-action-card">
               <div class="card-header ">
                
                 <div class="card-title">
                   <h3 style="">Choose Your Action</h3>
                 </div>
               </div>
               <div class="card-body">
                
                  <h4 style="margin-bottom: 40px;" id="quest">Do You Want To: </h4>
                  
                  <button class="btn btn-info btn-action" id="add-new-sub-admin-btn">Add New Sub Admin</button>
               </div>
             </div> 
             <div class="card" style="display: none;" id="add-new-sub-admin-card">
               <div class="card-header card-header-blue card-header-icon">
                 <div class="card-icon">
                   <i class="material-icons">contacts</i>
                 </div>
                 <div class="card-title">
                   <h4 style="">Add Admin Login Info</h4>
                 </div>
               </div>
               <div class="card-body">
                  <?php $attr = array('id' => 'form' ) ?>
                 <?php echo form_open('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/add_admin/admin_form#form',$attr); ?>
                 <div class="form-group bmd-form-group">
                    <label for="title" class="bmd-label-floating text-blue">Email Address</label>
                    <input type="email" id="email" name="email" class="form-control" value="<?php echo set_value('email') ?>" required>
                    <span class="form-error"><?php echo form_error('email'); ?></span>
                  </div>
                 <div class="form-group bmd-form-group">
                    <label for="title" class="bmd-label-floating text-blue">Title</label>
                    <input type="text" id="title" name="title" class="form-control" value="<?php echo set_value('title') ?>" required>
                    <span class="form-error"><?php echo form_error('title'); ?></span>
                  </div>
                  <div class="form-group bmd-form-group">
                    <label for="full_name" class="bmd-label-floating text-blue">Full Name</label>
                    <input type="text" id="full_name" name="full_name" class="form-control" value="<?php echo set_value('full_name') ?>" required>
                    <span class="form-error"><?php echo form_error('full_name'); ?></span>
                  </div>
                  <div class="form-group bmd-form-group">
                    <label for="qualification" class="bmd-label-floating text-blue">Qualification(s)</label>
                    <input type="text" id="qualification" name="qualification" class="form-control" value="<?php echo set_value('qualification') ?>" required>
                    <span class="form-error"><?php echo form_error('qualification'); ?></span>
                  </div>
                  <div class="form-group bmd-form-group">
                    <label for="user_name" class="bmd-label-floating text-blue">User name</label>
                    <input type="text" id="user_name" name="user_name" class="form-control" value="<?php echo set_value('user_name') ?>" required>
                    <span class="form-error"><?php echo form_error('user_name'); ?></span>
                  </div>
                  <div class="form-group bmd-form-group" style="margin-top: 15px;">
                    <label for="password" class="bmd-label-floating text-blue">Password</label>
                    <input type="password" id="password" name="password" class="form-control" value="<?php echo set_value('password') ?>" required>
                    <span class="form-error"><?php echo form_error('password'); ?></span>
                  </div>
                  <input type="submit" name="submit" class="btn btn-info btn-blue" style="margin-top: 30px;">
                  <input type="hidden" name="random_bytes" value='<?php echo bin2hex($this->encryption->create_key(16)); ?>'>
                 <?php echo form_close(); ?>
               </div>
             </div>

             
            </div>
          </div>
          
        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
          <footer>&copy; <?php echo date("Y"); ?> Copyright (OneHealth Issues Global Limited). All Rights Reserved</footer>
        </div>
      </footer>
  </div>
  
  
</body>
<script>
    $(document).ready(function() {
      $("table").DataTable();
      //First Button Clicked
      $("#add-new-sub-admin-btn").click(function(evt){
        $("#choose-action-card").hide("slow");
        $("#add-new-sub-admin-card").show("slow");
        $("#add-new-sub-admin-card").before("<button class='btn btn-warning go-back' onclick='goDefault()'>Go Back</button>");

      });

      //Second Button Clicked
      $("#list-sub-admins-btn").click(function (evt) {
        $("#choose-action-card").hide("slow");
        $("#select-sub-admin-card").show("slow");
        $("#add-new-sub-admin-card").before("<button class='btn btn-warning go-back' onclick='goDefault()'>Go Back</button>");
      });

      //Select Admin Form Submit event
      $("#select-sub-admin-form").submit(function(evt){
        evt.preventDefault();
      });

      //Onkeyup event for select sub admin form input field
      $("#admin-user-name").keyup(function(evt){
        var get_sub_admins_url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/get_sub_admins'); ?>";
        $(".spinner-overlay").show();
        $.ajax({
          url : get_sub_admins_url,
          type : "POST",
          responseType : "text",
          dataType : "text",
          data : "edit_tests=true",
          success : function(response){
            $(".spinner-overlay").hide();
            console.log(response);
          },
          error :function(){

          }
        })
      });

     

      <?php
        if($something_wrong == true){
      ?>
        swal({
          text: "Sorry Something Went Wrong Please Try Again",
          type: 'error'
          
          
        }).then((result) => {
          // if (result.value) {
            
          // }
        })
      <?php
        }
        if(isset($fivth_addition)){
          if($fivth_addition == "admin_form"){
      ?>  
        $("#choose-action-card").hide();
        $("#add-new-sub-admin-card").show();
        $("#add-new-sub-admin-card").before("<button class='btn btn-warning go-back' onclick='goDefault()'>Go Back</button>");
      <?php 
          }  
        }
      ?>

    });
  </script>
