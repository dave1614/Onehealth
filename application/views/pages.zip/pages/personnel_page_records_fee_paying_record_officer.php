       <?php
        if(is_array($curr_health_facility_arr)){
          foreach($curr_health_facility_arr as $row){
            $health_facility_id = $row->id;
            $health_facility_name = $row->name;
            $health_facility_logo = $row->logo;
            $health_facility_structure = $row->facility_structure;
            $health_facility_email = $row->email;
            $health_facility_phone = $row->phone;
            $health_facility_country = $row->country;
            $health_facility_state = $row->state;
            $health_facility_address = $row->address;
            $health_facility_table_name = $row->table_name;
            $health_facility_date = $row->date;
            $health_facility_time = $row->time;
            $health_facility_slug = $row->slug;
            $color = $row->color;
          }
          if(is_null($health_facility_logo)){
            $no_logo = true;
            
            $data_url_img = "<img style='display:none;' id='facility_img' width='100' height='100' class='round img-raised rounded-circle img-fluid' avatar='".$health_facility_name."' col='".$color."'>";
            
          }
          $admin = false;
          $user_id = $this->onehealth_model->getUserIdWhenLoggedIn();
        }
      ?>

<style>
  tr{
    cursor: pointer;
  }
</style>

<script>
  

  function goDefault() {
    
    document.location.reload();
  }

  function performActions (elem,evt) {
    $("#main-card").hide();
    $("#choose-action-card").show();
  }

  function goBackFromChooseActionCard (elem,evt) {
    $("#main-card").show();
    $("#choose-action-card").hide();
  }

  function inputNewCodes (elem,evt) {
    evt.preventDefault();
    $("#choose-action-card").hide();
    $("#input-new-codes-card").show();
  }

  function goBackFromInputCodesCard (elem,evt) {
    $("#choose-action-card").show();
    $("#input-new-codes-card").hide();
  }
  function inputCodesInfoBtn(elem,evt){
    evt.preventDefault();
  }

  function viewAndUpdateCodes(elem,evt){
    evt.preventDefault();
    swal({
      title: 'Choose Action',
      text: "Do You Want To View: ",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Used Codes',
      cancelButtonText: 'Unused Codes'
    }).then(function(){
      var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/view_used_codes_records') ?>";
      // var pdf = btoa(doc.output());
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : "show_records=true",
        
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response.success == true && response.messages != ""){
            var messages = response.messages;
            $("#used-codes-card .card-body").html(messages);
            $("#used-codes-table").DataTable();
            $("#choose-action-card").hide();
            $("#used-codes-card").show();
          }else{
            $.notify({
            message:"No Record To Display"
            },{
              type : "warning"  
            });
          }
        },
        error : function () {
          $(".spinner-overlay").hide();
          $.notify({
          message:"Something Went Wrong"
          },{
            type : "danger"  
          });
        }
      })
    }, function(dismiss){
      var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/view_unused_codes_records') ?>";
      // var pdf = btoa(doc.output());
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : "show_records=true",
        
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response.success == true && response.messages != ""){
            var messages = response.messages;
            $("#unused-codes-card .card-body").html(messages);
            $("#unused-codes-table").DataTable();
            $("#choose-action-card").hide();
            $("#unused-codes-card").show();
          }else{
            $.notify({
            message:"No Record To Display"
            },{
              type : "warning"  
            });
          }
        },
        error : function () {
          $(".spinner-overlay").hide();
          $.notify({
          message:"Something Went Wrong"
          },{
            type : "danger"  
          });
        }
      })
    });
  }

  function goBackFromUsedCodesCard (elem,evt) {
    $("#choose-action-card").show();
    $("#used-codes-card").hide();
  }

  function goBackFromUnUsedCodesCard (elem,evt) {
    $("#choose-action-card").show();
    $("#unused-codes-card").hide();
  }

  function viewUnusedCodesRecord(elem,evt,id){
    console.log(id);
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_unused_codes_record_info') ?>";
      // var pdf = btoa(doc.output());
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : "show_records=true&id="+id,
        
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response.success == true && response.messages.length != 0){
            var messages = response.messages;
            var id = messages.id;
            var code = messages.code;
            $("#edit-code-form").attr("data-id",id);
            $("#unused-code-info-card #code").html(code);
            for (const [key, value] of Object.entries(messages)) {
              $("#unused-code-info-card #" +key).val(value);
              if(key == "name_code_authentication" || key == "type"){
                $("#unused-code-info-card #" +value).prop("checked",true);
              }
            }

            $("#unused-code-info-card").show();  
            $("#unused-codes-card").hide();  
          }else{
            $.notify({
          message:"Something Went Wrong"
          },{
            type : "danger"  
          });
          }
        },
        error : function () {
          $(".spinner-overlay").hide();
          $.notify({
          message:"Something Went Wrong"
          },{
            type : "danger"  
          });
        }
      })
  }

  function goBackFromUnUsedCodeInfoCard (elem,evt) {
    $("#unused-code-info-card").hide();  
    $("#unused-codes-card").show();  
  }
</script>
      <!-- End Navbar -->
      <div class="spinner-overlay" style="display: none;">
        <div class="spinner-well">
          <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
        </div>
      </div>
     
      <div class="content" tabindex="-1">
        <div class="container-fluid">
         
          <h2 class="text-center"><?php echo $health_facility_name; ?></h2>
          <?php
            $logged_in_user_name = $user_name;
            $user_position = $this->onehealth_model->getUserPosition($health_facility_table_name,$user_id);
            $personnel_info = $this->onehealth_model->getPersonnelBySlug($fourth_addition);
            if(is_array($personnel_info)){
              
              foreach($personnel_info as $personnel){
                $personnel_id = $personnel->id;
                $spersonnel_dept_name = $personnel->name;
                $personnel_slug = $personnel->slug;
                $personnel_sub_dept = $personnel->sub_dept_id;
                $personnel_num = $this->onehealth_model->getPersonnelNum($health_facility_table_name,$second_addition,$third_addition,$personnel_slug);
                
                  $health_facility_table_info = $this->onehealth_model->getHealthFacilityTableBySubDeptDeptAndPosition($health_facility_table_name,$second_addition,$third_addition,$fourth_addition);
                  if(is_array($health_facility_table_info)){
                    foreach($health_facility_table_info as $user){
                      $personnel_user_name = $user->user_name;
                      $user_name_slug = url_title($personnel_user_name);
                    }
                  }
                
              }
            }
          ?>
          <?php
           if($this->onehealth_model->checkIfUserIsATopAdmin2($health_facility_table_name,$user_id)){ ?>
          <span style="text-transform: capitalize; font-size: 13px;" ><a class="text-info" href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/admin') ?>"><?php echo $dept_name; ?></a>&nbsp;&nbsp; > >  <a href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/'.$third_addition.'/admin') ?>" class="text-info"><?php echo $sub_dept_name; ?></a> &nbsp;&nbsp; > > <?php echo $personnel_name; ?></span>
          <?php  } elseif($user_position == "sub_admin"){ ?>
           <span style="text-transform: capitalize; font-size: 13px;" ><a href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/'.$sub_dept_slug.'/admin') ?>" class="text-info"><?php echo $sub_dept_name; ?></a> &nbsp;&nbsp; > > <?php echo $personnel_name; ?></span>
          <?php  } ?>
          <h3 class="text-center" style="text-transform: capitalize;"><?php echo $personnel_name; ?></h3>
          <?php if($user_position == "admin" || $user_position == "sub_admin"){ ?>
            <?php if($personnel_num > 0){ ?>
          <h4>No. Of Personnel: <a href="<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/personnel') ?>"><?php echo $personnel_num; ?></a></h4>
        <?php } ?>
          <?php } ?>
          <div class="row">
            <div class="col-sm-12">

              <div class="card" id="main-card">
                <div class="card-header">
                  <h3 class="card-title" id="welcome-heading">Welcome <?php echo $logged_in_user_name; ?></h3>
                </div>
                <div class="card-body">
                  <button style="margin-top: 50px;" onclick="performActions(this,event)" class="btn btn-info">Perform Actions</button>
                </div>
              </div>

              <div class="card" id="choose-action-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromChooseActionCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Choose Action: </h3>
                </div>
                <div class="card-body">

                  <table class="table">
                    <tbody>
                      <tr class="pointer-cursor">
                        <td>1</td>
                        <td><a href="#" onclick="inputNewCodes(this,event)">Input New Codes</a></td>
                      </tr>
                      <tr class="pointer-cursor">
                        <td>2</td>
                        <td><a href="#" onclick="viewAndUpdateCodes(this,event)">View And Update Codes</a></td>
                      </tr>
                      
                      <tr class="pointer-cursor">
                        <td>3</td>
                        <td><a href="#" onclick="mailSelectedCodes(this,event)">Mail Selected Codes</a></td>
                      </tr>
                      
                    </tbody>
                  </table>
                </div>
              </div>

              <div class="card" id="used-codes-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromUsedCodesCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Used Code </h3>
                </div>
                <div class="card-body">

                </div>
              </div>

              <div class="card" id="unused-codes-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromUnUsedCodesCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Unused Code </h3>
                </div>
                <div class="card-body">

                </div>
              </div>


              <div class="card" id="unused-code-info-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromUnUsedCodeInfoCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Edit This Unused Code </h3>
                </div>
                <div class="card-body">
                  <?php $attr = array('id' => 'edit-code-form') ?>
                  <?php echo form_open('',$attr); ?>
                  <span class="form-error text-right">* </span>: required
                  
                  <div class="wrap">
                    <div class="form-row">             
                      <div class="form-group col-sm-6">
                        <label for="firstname" class="label-control"><span class="form-error1">*</span>  First Name: </label>
                        <input type="text" class="form-control" id="firstname" name="firstname">
                        <span class="form-error"></span>
                      </div>
                      <div class="form-group col-sm-6">
                        <label for="lastname" class="label-control"><span class="form-error1">*</span> Last Name: </label>
                        <input type="text" class="form-control" id="lastname" name="lastname">
                        <span class="form-error"></span>
                      </div>


                      <h5>Code: </h5>
                      <p class="col-sm-6" id="code"></p>

                      <div class="form-group col-sm-6">
                        <p class="label"><span class="form-error1">*</span>Client Stratification: </p>
                        <div id="stratification">
                          <div class="form-check form-check-radio form-check-inline">
                            <label class="form-check-label">
                              <input class="form-check-input" type="radio" name="stratification" value="pfp" id="pfp" checked> Part Fee Paying
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                            </label>
                          </div>
                          <div class="form-check form-check-radio form-check-inline">
                            <label class="form-check-label">
                              <input class="form-check-input" type="radio" name="stratification" value="nfp" id="nfp"> None Fee Paying
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                            </label>
                          </div>
                          
                        </div>
                        <span class="form-error"></span>
                      </div>

                      <div class="form-group col-sm-6">
                        <p class="label"><span class="form-error1">*</span>Name Code Authentication: <a href="#" onclick="inputCodesInfoBtn(this,event)" class="btn btn-secondary" data-container="body" data-toggle="popover" data-placement="top" data-content="Here you determine if you want the code inputted by the front desk Record officers to match code only or name and names, before authentication and subsequent authorisation to be registered as non-fee-paying or part-fee-paying. Check the box to make your choice.">?</a></p>
                        <div id="code_authentication">
                          <div class="form-check form-check-radio form-check-inline">
                            <label class="form-check-label">
                              <input class="form-check-input" type="radio" name="code_authentication" value="1" id="1"> Yes
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                            </label>
                          </div>
                          <div class="form-check form-check-radio form-check-inline">
                            <label class="form-check-label">
                              <input class="form-check-input" type="radio" name="code_authentication" value="0" id="0" checked> No
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                            </label>
                          </div>
                          
                        </div>
                        <span class="form-error"></span>
                      </div>
                    </div>
                  </div>
                  <input type="submit" class="btn btn-primary">
                </form>
                </div>
              </div>



              <div class="card" id="input-new-codes-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromInputCodesCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Input New Code</h3>
                </div>
                <div class="card-body">
                  <?php $attr = array('id' => 'input-code-form') ?>
                  <?php echo form_open('',$attr); ?>
                  <span class="form-error text-right">* </span>: required
                  
                  <div class="wrap">
                    <div class="form-row">             
                      <div class="form-group col-sm-6">
                        <label for="firstname" class="label-control"><span class="form-error1">*</span>  First Name: </label>
                        <input type="text" class="form-control" id="firstname" name="firstname">
                        <span class="form-error"></span>
                      </div>
                      <div class="form-group col-sm-6">
                        <label for="lastname" class="label-control"><span class="form-error1">*</span> Last Name: </label>
                        <input type="text" class="form-control" id="lastname" name="lastname">
                        <span class="form-error"></span>
                      </div>

                      <div class="form-group col-sm-6">
                        <label for="code" class="label-control"><span class="form-error1">*</span> Code: </label>
                        <input type="text" class="form-control" id="code" name="code">
                        <span class="form-error"></span>
                      </div>

                      <div class="form-group col-sm-6">
                        <p class="label"><span class="form-error1">*</span>Client Stratification: </p>
                        <div id="stratification">
                          <div class="form-check form-check-radio form-check-inline">
                            <label class="form-check-label">
                              <input class="form-check-input" type="radio" name="stratification" value="pfp" id="pfp" checked> Part Fee Paying
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                            </label>
                          </div>
                          <div class="form-check form-check-radio form-check-inline">
                            <label class="form-check-label">
                              <input class="form-check-input" type="radio" name="stratification" value="nfp" id="nfp"> None Fee Paying
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                            </label>
                          </div>
                          
                        </div>
                        <span class="form-error"></span>
                      </div>

                      <div class="form-group col-sm-6">
                        <p class="label"><span class="form-error1">*</span>Name Code Authentication: <a href="#" onclick="inputCodesInfoBtn(this,event)" class="btn btn-secondary" data-container="body" data-toggle="popover" data-placement="top" data-content="Here you determine if you want the code inputted by the front desk Record officers to match code only or name and names, before authentication and subsequent authorisation to be registered as non-fee-paying or part-fee-paying. Check the box to make your choice.">?</a></p>
                        <div id="code_authentication">
                          <div class="form-check form-check-radio form-check-inline">
                            <label class="form-check-label">
                              <input class="form-check-input" type="radio" name="code_authentication" value="1" id="1"> Yes
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                            </label>
                          </div>
                          <div class="form-check form-check-radio form-check-inline">
                            <label class="form-check-label">
                              <input class="form-check-input" type="radio" name="code_authentication" value="0" id="0" checked> No
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                            </label>
                          </div>
                          
                        </div>
                        <span class="form-error"></span>
                      </div>
                    </div>
                  </div>
                  <input type="submit" class="btn btn-primary">
                </form>
                </div>
              </div>
                
             
            </div>
          </div>
        </div>
      </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
           <!-- <footer>&copy; <?php echo date("Y"); ?> Copyright (OneHealth Issues Global Limited). All Rights Reserved </footer> -->
        </div>
      </footer>
  </div>
  
  
</body>
<script>
    $(document).ready(function() {

      $("#edit-code-form").submit(function (evt) {
        evt.preventDefault();
        var me = $(this);
        var id= me.attr("data-id");

        
        var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/submit_pfp_nfp_verification_code_edit'); ?>";
        var values = me.serializeArray();
        values = values.concat({
          "name" : "id",
          "value" : id
        })
        
        console.log(values)
        $(".spinner-overlay").show();
        $.ajax({
          url : url,
          type : "POST",
          responseType : "json",
          dataType : "json",
          data : values,
          success : function (response) {
            console.log(response)
            $(".spinner-overlay").hide();
            if(response.success == true){
              $.notify({
              message:"Edited Succesfully"
              },{
                type : "success"  
              });
              
            }
            else{
             $.each(response.messages, function (key,value) {

              var element =  me.find('#'+key);
              
              element.closest('div.form-group')
                      
                      .find('.form-error').remove();
              element.after(value);
              
             });
              $.notify({
              message:"Some Values Where Not Valid. Please Enter Valid Values"
              },{
                type : "warning"  
              });
            }
          },
          error: function (jqXHR,textStatus,errorThrown) {
            $(".spinner-overlay").hide();
             $.notify({
              message:"Sorry Something Went Wrong"
              },{
                type : "danger"  
              });
            $(".form-error").html();
          }
        });  
      })

      $("#input-code-form").submit(function (evt) {
        evt.preventDefault();
        var me = $(this);
        
        var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/submit_pfp_nfp_verification_code'); ?>";
        var values = me.serializeArray();

        
        console.log(values)
        $(".spinner-overlay").show();
        $.ajax({
          url : url,
          type : "POST",
          responseType : "json",
          dataType : "json",
          data : values,
          success : function (response) {
            console.log(response)
            $(".spinner-overlay").hide();
            if(response.success == true){
              $.notify({
              message:"Code Added Succesfully"
              },{
                type : "success"  
              });
              setTimeout(goDefault, 1000);
              
            }
            else{
             $.each(response.messages, function (key,value) {

              var element =  me.find('#'+key);
              
              element.closest('div.form-group')
                      
                      .find('.form-error').remove();
              element.after(value);
              
             });
              $.notify({
              message:"Some Values Where Not Valid. Please Enter Valid Values"
              },{
                type : "warning"  
              });
            }
          },
          error: function (jqXHR,textStatus,errorThrown) {
            $(".spinner-overlay").hide();
             $.notify({
              message:"Sorry Something Went Wrong"
              },{
                type : "danger"  
              });
            $(".form-error").html();
          }
        });  
      })

      
      <?php
        if($no_admin == true && $this->onehealth_model->checkIfUserIsAdminOrSubAdmin($health_facility_table_name,$user_name)){
      ?>
        swal({
          title: 'Warning?',
          text: "You do not currently have any personnel in this section. Do Want To Add One?",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, add!'
        }).then((result) => {
          // if (result.value) {
            window.location.assign("<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/'.$sub_dept_slug.'/add_admin') ?>")
            
          // }
        })
      <?php
        }
      ?>

    });

  </script>
