       <?php
      if(is_array($curr_health_facility_arr)){
        foreach($curr_health_facility_arr as $row){
          $health_facility_id = $row->id;
          $health_facility_name = $row->name;
          $health_facility_logo = $row->logo;
          $health_facility_structure = $row->facility_structure;
          $health_facility_email = $row->email;
          $health_facility_phone = $row->phone;
          $health_facility_country = $this->onehealth_model->getCountryById($row->country);
          $health_facility_state = $this->onehealth_model->getStateById($row->state);
          $health_facility_address = $row->address;
          $health_facility_table_name = $row->table_name;
          $health_facility_date = $row->date;
          $health_facility_time = $row->time;
          $health_facility_slug = $row->slug;
          $color = $row->color;
        }
        $user_id = $this->onehealth_model->getUserIdWhenLoggedIn();
       $data_url_img = "<img style='display:none;' id='facility_img' width='100' height='100' class='round img-raised rounded-circle img-fluid' avatar='".$health_facility_name."' col='".$color."'>";
      }
    ?>
<style>
  tr{
    cursor: pointer;
  }
</style>
<script>

  function performActions (elem,evt) {
    $("#main-card").hide();
    $("#choose-action-card").show();
  }

  function goBackFromChooseActionCard (elem,evt) {
    $("#main-card").show();
    $("#choose-action-card").hide(); 
  }

  function viewHospitalTeller (elem,evt) {
    evt.preventDefault();
    $("#choose-action-card").hide();
    $("#hospital-teller-card").show();
  }

  function goBackHospitalTellerCard (elem,evt) {
    $("#choose-action-card").show();
    $("#hospital-teller-card").hide();
  }

  function viewRegistrationFees (elem,evt) {
    $("#choose-patient-type-registration").modal("show");
  }

  function viewConsultationFees (elem,evt) {
    $("#choose-patient-type-consultation").modal("show");
  }

  function viewAdmissionFees (elem,evt) {
    $("#choose-patient-type-admission").modal("show");
  }

  function viewWardServices (elem,evt) {
    $("#choose-patient-type-services").modal("show");
  }

  function viewOutstandingBillsCollected (elem,evt) {
    $("#choose-patient-type-outstanding").modal("show");
  }

  function selectTimeRangeRegistrationChanged(elem,event){
    var days_num = $(elem).val();
    var type = $(elem).attr("data-type");
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_registration_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num="+days_num+"&type="+type,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#view-registration-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#registration-table").DataTable();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function viewFullPayingRegistrationPayments (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_registration_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=fp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-registration").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-registration-payments-card .card-title").html("Registration Payments For Full Payment Patients");
          $("#view-registration-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#registration-table").DataTable();
          $("#view-registration-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }  

  function goBackFromViewRegistrationPaymentsCard (elem,evt) {
    $("#choose-patient-type-registration").modal("show");
    $("#hospital-teller-card").show();
    $("#view-registration-payments-card").hide();
  }

  function viewPartPayingRegistrationPayments (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_registration_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=pfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-registration").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-registration-payments-card .card-title").html("Registration Payments For Part Payment Patients");
          $("#view-registration-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#registration-table").DataTable();
          $("#view-registration-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function viewNonePayingRegistrationPayments (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_registration_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=nfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-registration").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-registration-payments-card .card-title").html("Registration Payments For Non Fee Payment Patients");
          $("#view-registration-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#registration-table").DataTable();
          $("#view-registration-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function viewFullPayingConsultationPayments (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_consultation_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=fp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-consultation").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-consultation-payments-card .card-title").html("Consultation Payments For Full Payment Patients");
          $("#view-consultation-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#consultation-table").DataTable();
          $("#view-consultation-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function selectTimeRangeConsultationChanged(elem,event){
    var days_num = $(elem).val();
    var type = $(elem).attr("data-type");
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_consultation_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num="+days_num+"&type="+type,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#view-consultation-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#consultation-table").DataTable();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function goBackFromViewConsultationPaymentsCard (elem,evt) {
    $("#choose-patient-type-consultation").modal("show");
    $("#hospital-teller-card").show();
    $("#view-consultation-payments-card").hide();
  }

  function viewPartPayingConsultationPayments (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_consultation_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=pfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-consultation").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-consultation-payments-card .card-title").html("Consultation Payments For Part Payment Patients");
          $("#view-consultation-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#consultation-table").DataTable();
          $("#view-consultation-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }


  function viewNonePayingConsultationPayments (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_consultation_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=nfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-consultation").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-consultation-payments-card .card-title").html("Consultation Payments For Non Fee Payment Patients");
          $("#view-consultation-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#consultation-table").DataTable();
          $("#view-consultation-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }


  function viewFullPayingAdmissionPayments (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_admission_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=fp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-admission").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-admission-payments-card .card-title").html("Ward Admission Payments For Full Payment Patients");
          $("#view-admission-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#admission-table").DataTable();
          $("#view-admission-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  } 


  function selectTimeRangeAdmissionChanged(elem,event){
    var days_num = $(elem).val();
    var type = $(elem).attr("data-type");
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_admission_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num="+days_num+"&type="+type,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#view-admission-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#admission-table").DataTable();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function goBackFromViewAdmissionPaymentsCard (elem,evt) {
    $("#choose-patient-type-admission").modal("show");
    $("#hospital-teller-card").show();
    $("#view-admission-payments-card").hide();
  }

  function viewPartPayingAdmissionPayments (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_admission_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=pfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-admission").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-admission-payments-card .card-title").html("Ward Admission Payments For Part Payment Patients");
          $("#view-admission-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#admission-table").DataTable();
          $("#view-admission-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function viewNonePayingAdmissionPayments (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_admission_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=nfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-admission").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-admission-payments-card .card-title").html("Ward Admission Payments For Non Fee Payment Patients");
          $("#view-admission-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#admission-table").DataTable();
          $("#view-admission-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function viewFullPayingWardServices (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_services_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=fp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-services").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-services-payments-card .card-title").html("Ward Services Payments For Full Payment Patients");
          $("#view-services-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#services-table").DataTable();
          $("#view-services-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function selectTimeRangeServicesChanged(elem,event){
    var days_num = $(elem).val();
    var type = $(elem).attr("data-type");
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_services_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num="+days_num+"&type="+type,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#view-services-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#services-table").DataTable();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function goBackFromViewServicesPaymentsCard (elem,evt) {
    $("#choose-patient-type-services").modal("show");
    $("#hospital-teller-card").show();
    $("#view-services-payments-card").hide();
  }

  function viewPartPayingWardServices (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_services_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=pfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-services").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-services-payments-card .card-title").html("Ward Services Payments For Part Payment Patients");
          $("#view-services-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#services-table").DataTable();
          $("#view-services-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function viewNonePayingWardServices (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_services_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=nfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-services").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-services-payments-card .card-title").html("Ward Services Payments For Non Fee Payment Patients");
          $("#view-services-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#services-table").DataTable();
          $("#view-services-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }


  function viewFullPayingOutstanding (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_outstanding_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=fp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-outstanding").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-outstanding-payments-card .card-title").html("Outstanding Payments For Full Payment Patients");
          $("#view-outstanding-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#outstanding-table").DataTable();
          $("#view-outstanding-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function goBackFromViewOutstandingPaymentsCard (elem,evt) {
    $("#choose-patient-type-outstanding").modal("show");
    $("#hospital-teller-card").show();
    $("#view-outstanding-payments-card").hide();
  }

  function selectTimeRangeOutstandingChanged(elem,event){
    var days_num = $(elem).val();
    var type = $(elem).attr("data-type");
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_outstanding_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num="+days_num+"&type="+type,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#view-outstanding-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#outstanding-table").DataTable();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }


  function viewPartPayingOutstanding (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_outstanding_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=pfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-outstanding").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-outstanding-payments-card .card-title").html("Outstanding Payments For Part Payment Patients");
          $("#view-outstanding-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#outstanding-table").DataTable();
          $("#view-outstanding-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function viewNonePayingOutstanding (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_outstanding_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=nfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-outstanding").modal("hide");
          $("#hospital-teller-card").hide();
          $("#view-outstanding-payments-card .card-title").html("Outstanding Payments For Non Fee Payment Patients");
          $("#view-outstanding-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#outstanding-table").DataTable();
          $("#view-outstanding-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }


  function viewPharmacy (elem,evt) {
    evt.preventDefault();
    $("#choose-patient-type-pharmacy").modal("show");
  }

  function viewFullPayingPharmacy (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_pharmacy_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=fp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-pharmacy").modal("hide");
          $("#choose-action-card").hide();
          $("#view-pharmacy-payments-card .card-title").html("Pharmacy Payments For Full Payment Patients");
          $("#view-pharmacy-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#pharmacy-table").DataTable();
          $("#view-pharmacy-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function goBackFromViewPharmacyPaymentsCard (elem,evt) {
    $("#choose-patient-type-pharmacy").modal("show");
    $("#choose-action-card").show();
   
    $("#view-pharmacy-payments-card").hide();
  }

  function selectTimeRangePharmacyChanged(elem,event){
    var days_num = $(elem).val();
    var type = $(elem).attr("data-type");
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_pharmacy_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num="+days_num+"&type="+type,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#view-pharmacy-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#pharmacy-table").DataTable();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function viewPartPayingPharmacy (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_pharmacy_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=pfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-pharmacy").modal("hide");
          $("#choose-action-card").hide();
          $("#view-pharmacy-payments-card .card-title").html("Pharmacy Payments For Part Payment Patients");
          $("#view-pharmacy-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#pharmacy-table").DataTable();
          $("#view-pharmacy-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }


  function viewNonePayingPharmacy (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_pharmacy_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=nfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-pharmacy").modal("hide");
          $("#choose-action-card").hide();
          $("#view-pharmacy-payments-card .card-title").html("Pharmacy Payments For Non Fee Payment Patients");
          $("#view-pharmacy-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#pharmacy-table").DataTable();
          $("#view-pharmacy-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function viewLaboratory (elem,evt) {
    evt.preventDefault();
    $("#choose-patient-type-laboratory").modal("show");
  }

  function viewFullPayingLaboratory (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_laboratory_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=fp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-laboratory").modal("hide");
          $("#choose-action-card").hide();
          $("#view-laboratory-payments-card .card-title").html("Laboratory Payments For Full Payment Patients");
          $("#view-laboratory-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#laboratory-table").DataTable();
          $("#view-laboratory-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function selectTimeRangeLaboratoryChanged(elem,event){
    var days_num = $(elem).val();
    var type = $(elem).attr("data-type");
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_laboratory_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num="+days_num+"&type="+type,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#view-laboratory-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#laboratory-table").DataTable();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function goBackFromViewLaboraroryPaymentsCard (elem,evt) {
    $("#choose-patient-type-laboratory").modal("show");
    $("#choose-action-card").show();
    $("#view-laboratory-payments-card").hide();
  }

  function loadLaboratoryPaymentInfo (elem,evt) {
    elem = $(elem);
    var initiation_code = elem.attr("data-initiation-code");
    var name = elem.attr("data-name");
    console.log(initiation_code);
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_history_of_payment_laboratory_finance_records'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&initiation_code="+initiation_code,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#payment-history-lab-card .card-body").html(messages);
          $("#payment-history-lab-card .card-title").html("Payment History Of " + name);
          $("#payment-info-lab-table").DataTable({
            aLengthMenu: [
                [25, 50, 100, 200, -1],
                [25, 50, 100, 200, "All"]
            ],
            iDisplayLength: -1
          });
          $("#view-laboratory-payments-card").hide();
          $("#payment-history-lab-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }


  function goBackFromPaymentHistoryLabCard (elem,evt) {
    $("#payment-history-lab-card").hide();
    $("#view-laboratory-payments-card").show();
  }

  function viewPartPayingLaboratory (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_laboratory_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=pfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-laboratory").modal("hide");
          $("#choose-action-card").hide();
          $("#view-laboratory-payments-card .card-title").html("Laboratory Payments For Part Payment Patients");
          $("#view-laboratory-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#laboratory-table").DataTable();
          $("#view-laboratory-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function viewNonePayingLaboratory (elem,evt) {
    
    $(".spinner-overlay").show();
        
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_patients_laboratory_fees_default'); ?>";
    
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&days_num=1&type=nfp",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != ""){
          var messages = response.messages;
          $("#choose-patient-type-laboratory").modal("hide");
          $("#choose-action-card").hide();
          $("#view-laboratory-payments-card .card-title").html("Laboratory Payments For Non Fee Payment Patients");
          $("#view-laboratory-payments-card .card-body").html(messages);
          $('.my-select').selectpicker();
          $("#laboratory-table").DataTable();
          $("#view-laboratory-payments-card").show();
        }
        else{
         $.notify({
          message:"No Record To Display"
          },{
            type : "warning"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }


</script>
      <!-- End Navbar -->
      <div class="spinner-overlay" style="display: none;">
        <div class="spinner-well">
          <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
        </div>
      </div>
     
      <div class="content" tabindex="-1">
        <div class="container-fluid">
         
          <h2 class="text-center"><?php echo $health_facility_name; ?></h2>
          <?php
            $logged_in_user_name = $user_name;
            $user_position = $this->onehealth_model->getUserPosition($health_facility_table_name,$user_id);
            $personnel_info = $this->onehealth_model->getPersonnelBySlug($fourth_addition);
            if(is_array($personnel_info)){
              
              foreach($personnel_info as $personnel){
                $personnel_id = $personnel->id;
                $spersonnel_dept_name = $personnel->name;
                $personnel_slug = $personnel->slug;
                $personnel_sub_dept = $personnel->sub_dept_id;
                $personnel_num = $this->onehealth_model->getPersonnelNum($health_facility_table_name,$second_addition,$third_addition,$personnel_slug);
                
                  $health_facility_table_info = $this->onehealth_model->getHealthFacilityTableBySubDeptDeptAndPosition($health_facility_table_name,$second_addition,$third_addition,$fourth_addition);
                  if(is_array($health_facility_table_info)){
                    foreach($health_facility_table_info as $user){
                      $personnel_user_name = $user->user_name;
                      $user_name_slug = url_title($personnel_user_name);
                    }
                  }
                
              }
            }
          ?>
          <?php
           if(is_null($health_facility_logo)){
            echo $data_url_img; 
           }else{ 
            ?> 
          <img src="<?php echo base_url('assets/images/'.$health_facility_logo); ?>" style="display: none;" alt="" id="facility_img">
          <?php } ?>
          <?php

           if($this->onehealth_model->checkIfUserIsATopAdmin2($health_facility_table_name,$user_id)){ ?>
          <span style="text-transform: capitalize; font-size: 13px;" ><a class="text-info" href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/admin') ?>"><?php echo $dept_name; ?></a>&nbsp;&nbsp; > >  <a href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/'.$third_addition.'/admin') ?>" class="text-info"><?php echo $sub_dept_name; ?></a> &nbsp;&nbsp; > > <?php echo $personnel_name; ?></span>
          <?php  } elseif($user_position == "sub_admin"){ ?>
           <span style="text-transform: capitalize; font-size: 13px;" ><a href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/'.$sub_dept_slug.'/admin') ?>" class="text-info"><?php echo $sub_dept_name; ?></a> &nbsp;&nbsp; > > <?php echo $personnel_name; ?></span>
          <?php  } ?>
          <h3 class="text-center" style="text-transform: capitalize;"><?php echo $personnel_name; ?></h3>
          <?php if($user_position == "admin" || $user_position == "sub_admin"){ ?>
            <?php if($personnel_num > 0){ ?>
          <h4>No. Of Personnel: <a href="<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/personnel') ?>"><?php echo $personnel_num; ?></a></h4>
        <?php } ?>
          <?php } ?> 
          <div class="row">
            <div class="col-sm-12">

              


              <div class="card" id="main-card">
                <div class="card-header">
                  <h3 class="card-title" id="welcome-heading">Welcome <?php echo $logged_in_user_name; ?></h3>
                </div>
                <div class="card-body">
                  <button style="margin-top: 50px;" onclick="performActions(this,event)" class="btn btn-info">Perform Actions</button>
                </div>
              </div>

              <div class="card" id="hospital-teller-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-warning btn-round" onclick="goBackHospitalTellerCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading">Hospital Teller's Payments</h3>
                </div>
                <div class="card-body">
                  <table class="table">
                    <tbody>
                      <tr class="pointer-cursor">
                        <td>1</td>
                        <td><a href="#" onclick="viewRegistrationFees(this,event)">Registration Fees</a></td>
                      </tr>
                      <tr class="pointer-cursor">
                        <td>2</td>
                        <td><a href="#" onclick="viewConsultationFees(this,event)">Consultation Fees</a></td>
                      </tr>
                      <tr class="pointer-cursor">
                        <td>3</td>
                        <td><a href="#" onclick="viewAdmissionFees(this,event)">Wards Admission Fees</a></td>
                      </tr>
                      <tr class="pointer-cursor">
                        <td>4</td>
                        <td><a href="#" onclick="viewWardServices(this,event)">Wards Services</a></td>
                      </tr>
                      <tr class="pointer-cursor">
                        <td>5</td>
                        <td><a href="#" onclick="viewOutstandingBillsCollected(this,event)">Outstanding Bills Collected</a></td>
                      </tr>
                      
                     
                      
                    </tbody>
                  </table>
                </div>
              </div>

              

              <div class="card" id="choose-action-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromChooseActionCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">View Payments In: </h3>
                </div>
                <div class="card-body">

                  <table class="table">
                    <tbody>
                      <tr class="pointer-cursor">
                        <td>1</td>
                        <td><a href="#" onclick="viewHospitalTeller(this,event)">Hospital Teller</a></td>
                      </tr>
                      <tr class="pointer-cursor">
                        <td>2</td>
                        <td><a href="#" onclick="viewPharmacy(this,event)">Pharmacy</a></td>
                      </tr>
                      
                      <tr class="pointer-cursor">
                        <td>3</td>
                        <td><a href="#" onclick="viewLaboratory(this,event)">Laboratory</a></td>
                      </tr>

                      
                      
                    </tbody>
                  </table>
                </div>
              </div>

              <div class="card" id="view-registration-payments-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromViewRegistrationPaymentsCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">View Payments In: </h3>
                </div>
                <div class="card-body">

                </div>
              </div>

              <div class="card" id="payment-history-lab-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromPaymentHistoryLabCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">Payment History Of: </h3>
                </div>
                <div class="card-body">

                </div>
              </div>

              <div class="card" id="view-admission-payments-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromViewAdmissionPaymentsCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">View Payments In: </h3>
                </div>
                <div class="card-body">

                </div>
              </div>

              <div class="card" id="view-services-payments-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromViewServicesPaymentsCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">View Payments In: </h3>
                </div>
                <div class="card-body">

                </div>
              </div>

              <div class="card" id="view-outstanding-payments-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromViewOutstandingPaymentsCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">View Payments In: </h3>
                </div>
                <div class="card-body">

                </div>
              </div>

              <div class="card" id="view-pharmacy-payments-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromViewPharmacyPaymentsCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">View Payments In: </h3>
                </div>
                <div class="card-body">

                </div>
              </div>

              <div class="card" id="view-laboratory-payments-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromViewLaboraroryPaymentsCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">View Payments In: </h3>
                </div>
                <div class="card-body">

                </div>
              </div>

              <div class="card" id="view-consultation-payments-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-round btn-warning" onclick="goBackFromViewConsultationPaymentsCard(this,event)">Go Back</button>
                  <h3 class="card-title" id="welcome-heading" style="text-transform: capitalize;">View Payments In: </h3>
                </div>
                <div class="card-body">

                </div>
              </div>





            </div>
          </div>

          <div class="modal fade" data-backdrop="static" id="choose-patient-type-laboratory" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">View Laboratory Payments Of Patients That Are: </h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" id="modal-body">
                  <p>
                    <button class="btn btn-primary" onclick="viewFullPayingLaboratory(this,event)">Full Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-info" onclick="viewPartPayingLaboratory(this,event)">Part Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-success" onclick="viewNonePayingLaboratory(this,event)">None Paying</button>
                  </p>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
                </div>
              </div>
            </div>
          </div>

  
          <div class="modal fade" data-backdrop="static" id="choose-patient-type-pharmacy" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">View Pharmacy Payments Of Patients That Are: </h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" id="modal-body">
                  <p>
                    <button class="btn btn-primary" onclick="viewFullPayingPharmacy(this,event)">Full Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-info" onclick="viewPartPayingPharmacy(this,event)">Part Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-success" onclick="viewNonePayingPharmacy(this,event)">None Paying</button>
                  </p>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
                </div>
              </div>
            </div>
          </div>

          <div class="modal fade" data-backdrop="static" id="choose-patient-type-outstanding" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">View Outstanding Payments Of Patients That Are: </h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" id="modal-body">
                  <p>
                    <button class="btn btn-primary" onclick="viewFullPayingOutstanding(this,event)">Full Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-info" onclick="viewPartPayingOutstanding(this,event)">Part Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-success" onclick="viewNonePayingOutstanding(this,event)">None Paying</button>
                  </p>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
                </div>
              </div>
            </div>
          </div>

          <div class="modal fade" data-backdrop="static" id="choose-patient-type-services" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">View Ward Services Payments Of Patients That Are: </h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" id="modal-body">
                  <p>
                    <button class="btn btn-primary" onclick="viewFullPayingWardServices(this,event)">Full Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-info" onclick="viewPartPayingWardServices(this,event)">Part Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-success" onclick="viewNonePayingWardServices(this,event)">None Paying</button>
                  </p>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
                </div>
              </div>
            </div>
          </div>

          <div class="modal fade" data-backdrop="static" id="choose-patient-type-admission" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">View Ward Admission Payments Of Patients That Are: </h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" id="modal-body">
                  <p>
                    <button class="btn btn-primary" onclick="viewFullPayingAdmissionPayments(this,event)">Full Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-info" onclick="viewPartPayingAdmissionPayments(this,event)">Part Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-success" onclick="viewNonePayingAdmissionPayments(this,event)">None Paying</button>
                  </p>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
                </div>
              </div>
            </div>
          </div>

          <div class="modal fade" data-backdrop="static" id="choose-patient-type-consultation" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">View Consultation Payments Of Patients That Are: </h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" id="modal-body">
                  <p>
                    <button class="btn btn-primary" onclick="viewFullPayingConsultationPayments(this,event)">Full Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-info" onclick="viewPartPayingConsultationPayments(this,event)">Part Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-success" onclick="viewNonePayingConsultationPayments(this,event)">None Paying</button>
                  </p>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
                </div>
              </div>
            </div>
          </div>

          <div class="modal fade" data-backdrop="static" id="choose-patient-type-registration" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">View Registration Payments Of Patients That Are: </h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" id="modal-body">
                  <p>
                    <button class="btn btn-primary" onclick="viewFullPayingRegistrationPayments(this,event)">Full Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-info" onclick="viewPartPayingRegistrationPayments(this,event)">Part Paying</button>
                  </p>
                  <p>
                    <button class="btn btn-success" onclick="viewNonePayingRegistrationPayments(this,event)">None Paying</button>
                  </p>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
                </div>
              </div>
            </div>
          </div>

          <div class="modal fade" data-backdrop="static" id="consultation-fee-payment-modal-off-appointment" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">Mark This Patient Consultation Fee As Paid</h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>


                <div class="modal-body" id="modal-body">
                  <?php
                    $attr = array('id' => 'consultation-fee-payment-form-off-appointment');
                   echo form_open('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/submit_consultation_fee_paymemt_off_appointment',$attr);
                  ?>
                    <div class="form-group">
                      <label for="consultation_amt">Enter Consultation Fee</label>
                      <input type="number" name="consultation_amt" id="consultation_amt" class="form-control" required>
                      <span class="form-error"></span>
                    </div>
                    <input type="submit" class="btn btn-success" value="PROCEED">
      
                  </form>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
                </div>
              </div>
            </div>
          </div>

          <div class="modal fade" data-backdrop="static" id="consultation-fee-payment-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">Mark This Patient Consultation Fee As Paid</h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>


                <div class="modal-body" id="modal-body">
                  <?php
                    $attr = array('id' => 'consultation-fee-payment-form');
                   echo form_open('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/submit_consultation_fee_paymemt',$attr);
                  ?>
                    <div class="form-group">
                      <label for="consultation_amt">Enter Consultation Fee</label>
                      <input type="number" name="consultation_amt" id="consultation_amt" class="form-control" required>
                      <span class="form-error"></span>
                    </div>
                    <input type="submit" class="btn btn-success" value="PROCEED">
      
                  </form>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
                </div>
              </div>
            </div>
          </div> 

          <div class="modal fade" data-backdrop="static" id="mark-paid-patients-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">Mark This Patient As Paid</h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>


                <div class="modal-body" id="modal-body">
                  <?php
                    $attr = array('id' => 'registration-amount-form');
                   echo form_open('',$attr);
                  ?>
                    <div class="form-group">
                      <label for="registration_amt">Enter Registration Price</label>
                      <input type="number" name="registration_amt" id="registration_amt" class="form-control" required>
                      <span class="form-error"></span>
                    </div>
                    <input type="submit" class="btn btn-success" value="PROCEED">
      
                  </form>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
                </div>
              </div>
            </div>
          </div> 

          <div id="proceed-referral-to-nurse" onclick="proceedReferralToNurse(this,event)" rel="tooltip" data-toggle="tooltip" title="Push This Referral To Nurse For Inputing Of Vital Signs" style="background: #9c27b0; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; display: none; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
            <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
              <i class="material-icons" style="font-size: 25px; font-weight: normal; color: #fff;" aria-hidden="true">arrow_forward</i>
            </div>
          </div>

          <div id="mark-this-patient-registration-as-paid-btn" onclick="markThisPatientsRegistrationAsPaid(this,event)" rel="tooltip" data-toggle="tooltip" title="Mark This Patient Registration As Paid" style="background: #9c27b0; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; display: none; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
            <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
             <i class="fas fa-check-double" style="font-size: 25px; font-weight: normal; color: #fff;" aria-hidden="true"></i>
            </div>
          </div>


        </div>
      </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
           <!-- <footer>&copy; <?php echo date("Y"); ?> Copyright (OneHealth Issues Global Limited). All Rights Reserved </footer> -->
        </div>
      </footer>
  </div>
  
  
</body>
<script>
    $(document).ready(function() {

      
    });

  </script>
