<script>
  function unRegisterPatient (facility_table_name,hospital_name) {        
      var url = "<?php echo site_url('onehealth/unregister_patient'); ?>";
      var data = "table_name="+facility_table_name+"&facility_name="+hospital_name;
      var return_val = false;
      $(".spinner-overlay").show();
      $.ajax({
        url : url,
        type : "POST",
        responseType : "text",
        dataType : "text",
        data : data,
        async : false,
        success : function(response){
          console.log(response)
          $(".spinner-overlay").hide();
          if(response == "values_messed"){
            $.notify({
            message:"Sorry Something Went Wrong"
            },{
              type : "warning"  
            });
            
          }else if(response == "could not register patient"){
           $.notify({
            message:"Sorry You Could Not Be Registered"
            },{
              type : "warning"  
            });
           
          }else if(response == "already_registered"){
           $.notify({
            message:"Sorry You've Not Registered On This Facility"
            },{
              type : "warning"  
            });
           
          }else if(response == "successful"){
            $.notify({
            message:"Successfully Unregistered"
            },{
              type : "success"  
            });
            return_val = true;
          }
        },
        error: function () {
          $(".spinner-overlay").hide();
           $.notify({
            message:"Sorry You Could Not Be Registered"
            },{
              type : "danger"  
            });
        }
      })
   return return_val;
  }
</script>

      <div class="spinner-overlay" style="display: none;">
        <div class="spinner-well">
          <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
        </div>
      </div>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <h2>Welcome <?php echo $user_name; ?></h2>
          <div class="row">
            <div class="col-sm-10">
              <div class="card">
                <div class="card-header">
                  <h4 class="card-title">Health Facilities You Are Affiliated With</h4>
                </div>
                <div class="card-body">
                 
                    <?php
                    $affiliated_facilities = $this->onehealth_model->getUserAffiliatedFacilities($user_id);
                    $affiliated_facilities_arr = explode(',', $affiliated_facilities);
                    // print_r($affiliated_facilities_arr);
                    foreach ($affiliated_facilities_arr as $key => $value) {
                        if (empty($value)) {
                           unset($affiliated_facilities_arr[$key]);
                        }
                    }
                      if(!empty($affiliated_facilities_arr)){
                    ?>
                  <div class="table-responsive">
                  <table class="table table-test table-striped table-bordered nowrap hover display" id="example" cellspacing="0" width="100%" style="width:100%">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Affiliation</th>
                        <th class="text-right">Actions</th>
                      </tr>
                    </thead>
                    
                    <tbody>
                    <?php
                        $i = 0;
                        for($x = 0; $x < count($affiliated_facilities_arr); $x++) {
                          $affiliated_facility_table = $affiliated_facilities_arr[$x];
                          
                          $health_facility_table_arr = $this->onehealth_model->getUserInfoHealthFacilityById($affiliated_facility_table,$user_id);
                        
                        
                          if(is_array($health_facility_table_arr)){  
                                   
                            foreach($health_facility_table_arr as $row){
                              $i++;
                              $affiliation_id = $row->id;
                              $health_facility_name = $row->facility_name;
                              $position = $row->position;
                              $dept = $row->dept;
                              $dept_id = $this->onehealth_model->getDeptIdBySlug($dept);
                              $sub_dept = $row->sub_dept;
                              $sub_dept_id = $this->onehealth_model->getSubDeptIdBySlugAndDeptId($sub_dept,$dept_id);
                              $personnel = $row->personnel;
                              // $health_facility_slug = strtolower(url_title($health_facility_name));
                              $health_facility_id = $this->onehealth_model->getHealthFacilityIdByTableName($affiliated_facility_table);
                              $health_facility_slug = $this->onehealth_model->getHealthFacilitySlugByTableName($affiliated_facility_table);

                      ?>
                      <tr>
                        <td><?php echo $i; ?></td>
                        <td><a href="<?php echo site_url('onehealth/index/'.$health_facility_slug); ?>"><?php echo $health_facility_name; ?></a></td>
                        <td><?php if($position == "sub_admin"){ echo 'sub admin ('.$this->onehealth_model->getSubDeptNameBySlug($sub_dept,$dept_id).')'; }elseif($position == "personnel"){ echo 'personnel ('.$this->onehealth_model->getPersonnelNameBySlug($personnel,$sub_dept_id,$dept_id).')'; } else{ echo $position; } ?></td>
                        <td class="td-actions text-right">
                           <a href="<?php if($position == 'admin'){ echo site_url('onehealth/index/'.$health_facility_slug.'/'.'admin'); } elseif($position == 'sub_admin'){ echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept.'/'.$sub_dept.'/admin'); } elseif($position == 'personnel'){ echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept.'/'.$sub_dept.'/'.$personnel.'/admin'); } elseif($position == "patient"){ echo site_url('onehealth/index/'.$health_facility_slug); } ?>" rel="tooltip" data-toggle="tooltip" id="" title="Enter The Appropriate Panel" class="btn btn-primary">
                              <i class="fas fa-user-tie"></i>
                          </a>
                          <?php if($position == "patient"){ ?>
                          <a href="#" rel="tooltip" data-toggle="tooltip" id="resign" data-hospital-name1="<?php echo $affiliated_facility_table; ?>" data-hospital-name="<?php echo $health_facility_name ?>"   title="UnRegister" class="btn btn-danger">
                              <i class="fas fa-user-times"></i>
                          </a>
                          <?php } ?>
                        </td>
                      </tr>
                      <?php      
                          }
                        
                      ?>
                    

                   
                  <?php  
                          }else{
                            
                          }
                      }
                    }else{
                      echo "<p class='text-warning'>Sorry, You Are Not Affiliated With Any Facility.</p>";
                    }
                  ?>
                    </tbody>
                  </table>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
          <!-- <footer>&copy; <?php echo date("Y"); ?> Copyright (OneHealth Issues Global Limited). All Rights Reserved</footer> -->
        </div>
      </footer>
    </div>
  </div>
  <!--   Core JS Files   -->
 <script>
   $(document).ready(function () {
     var table = $('.table').DataTable();
     $('.table tbody').on( 'click', 'a#resign', function () {
        swal({
        title: 'Warning?',
        text: "Are You Sure You Want To Proceed?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Proceed'
      }).then((result) => {
   
        var facility_table_name = $(this).attr("data-hospital-name1");
        var hospital_name = $(this).attr("data-hospital-name");
        if(unRegisterPatient(facility_table_name,hospital_name) == true){
          table
        .row( $(this).parents('tr') )
        .remove()
        .draw();
        }
        
      });
      
    } );
   })
 </script>