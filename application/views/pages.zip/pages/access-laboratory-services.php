<?php
  if(is_array($curr_health_facility_arr)){
    foreach($curr_health_facility_arr as $row){
      $hospital_id = $row->id;
      $hospital_name = $row->name;
      $hospital_logo = $row->logo;
      $hopsital_email = $row->email;
      $hospital_phone = $row->phone;
      $hospital_country = $this->onehealth_model->getCountryById($row->country);
      $hospital_state = $this->onehealth_model->getStateById($row->state);
      $hospital_address = $row->address;
      $hospital_slug = $row->slug;
      $hospital_table_name = $row->table_name;
      $facility_structure = $row->facility_structure;
      $color = $row->color;
      $no_logo = false;
      $patient_bio_data_table = $this->onehealth_model->createpatientBioDataTableString($hospital_id,$hospital_name);
      
      $is_admin = $this->onehealth_model->checkIfUserIsAdminOfFacility($hospital_table_name,$user_id);
      $registered = false;
      if(!$is_admin){
        if($this->onehealth_model->checkIfUserIsRegisteredOnThisFacility($hospital_table_name,$user_name,$hospital_name,$user_id)){
          $registered = true;
        }else{
          $registered = false;
        }

        if($this->onehealth_model->checkIfBioDataHasBeenEnteredByPatient($patient_bio_data_table,$user_name,$user_id)){
          $bio_data_entered = true;
        }else{
          $bio_data_entered = false;
        }
      }

      if(is_null($hospital_logo)){
        $no_logo = true;
        if($is_admin == true){
          $hospital_logo = "<img width='100' height='100' class='round img-raised rounded-circle img-fluid logo-link-cont' avatar='".$hospital_name."' col='".$color."' rel='tooltip' data-original-title='Change Your Facility Logo' data-toggle='modal' data-target='#change-logo-modal' data-backdrop='false'>";
        }else{
          $hospital_logo = "<img width='100' height='100' class='round img-raised rounded-circle img-fluid' avatar='".$hospital_name."' col='".$color."'>";
        }
        
      }else{
        $logo_url = base_url('assets/images/'.$hospital_logo);
        if($is_admin == true){
          $hospital_logo = '<img src="'.$logo_url.'" alt="" width="100" height="100" class="round img-raised rounded-circle img-fluid logo-link-cont" rel="tooltip" data-original-title="Change Your Facility Logo" data-toggle="modal" data-target="#change-logo-modal" data-backdrop="false" style="width:100px; height:100px;">';
        }else{
          $hospital_logo = '<img src="'.$logo_url.'" alt="" width="100" height="100" class="round img-raised rounded-circle img-fluid" style="width:100px; height:100px;">';
        }
      }
      
    }
?>
<?php if(is_array($this->onehealth_model->getFirstSubDept(1))){ 
  foreach($this->onehealth_model->getFirstSubDept(1) as $row){
    $sub_dept_name = $row->name;
    $sub_dept_slug = $row->slug;
  }
  // $auth_url = $this->paystack->init("7PVGX8MEk85tgeEpVD", 50000, 'ikechukwunwogo@gmail.com',[
  //           'name'=>"Nwogo David",
            
  //           "Phone"=>"08127027321"
  //       ]);
  //       // redirect($auth_url);
  //       echo $auth_url;
        
        // $ver_info = $this->paystack->verifyTransaction('7PVGX8MEk85tgeE');
        // print_r($ver_info);

?>

<script>
  var tests_selected_obj = [];
  function goBackSubTests1(){
    $("#sub-tests-card").hide();
    $("#select-test-card").show();
    
  }

  function testRadioClicked(elem,e) {
    if (!e) var e = window.event;                // Get the window event
    e.cancelBubble = true;                       // IE Stop propagation
    if (e.stopPropagation) e.stopPropagation();  // Other Broswers
    var isChecked =  elem.checked;
    var main_test_id = elem.getAttribute("data-main-test-id");
    var test_id = elem.getAttribute("data-testid");
    var test_name = elem.getAttribute("data-testname");
    var test_cost = elem.getAttribute("rel");
    var ta_time = elem.getAttribute("data-testta");
    
    
    var patient_name = $("#name").html();
    var patient_user_name = $("#user_name").html();
    var sub_dept_id = elem.getAttribute("data-sub-dept-id");
    var health_facility_slug = elem.getAttribute("data-facility-slug");
    var sub_dept_slug = elem.getAttribute("data-sub-dept-slug");
    var dept_slug = elem.getAttribute("data-dept_slug");
    
    var record_id = elem.getAttribute("data-record-id");
    
    
    patient_name = $.trim(patient_name);
    var value = {
      "dept_slug" : dept_slug,
      "sub_dept_slug" : sub_dept_slug,
      "facility_slug" : health_facility_slug,
      "status" : "registered_patient",
      "patient_user_name" : patient_user_name,
      "main_test_id" : main_test_id,
      "test_id": test_id,
      "test_name":test_name,
      "test_cost" : test_cost,
      "ta_time" : ta_time,
      
      "patient_name" : patient_name,
      "sub_dept_id" : sub_dept_id,
      "record_id" : record_id
    };
    if(isChecked){
      tests_selected_obj.push(value)
    }else{      
      var index = tests_selected_obj.map(function(obj, index) {
          if(obj.test_id === test_id) {
              return index;
          }
      }).filter(isFinite);
      if(index > -1){
        tests_selected_obj.splice(index, 1);
      }
    }
    // console.log(tests_selected_obj)
  } 

  function copyText(text) {
    /* Get the text field */
    var elem = document.createElement("textarea");
    elem.value = text;
    document.body.append(elem);

    /* Select the text field */
    elem.select();
    /* Copy the text inside the text field */
    if(document.execCommand("copy")){
      $.notify({
      message:"Copied!"
      },{
        type : "success"  
      });
    }

    document.body.removeChild(elem);

    /* Alert the copied text */
  }

  function physicalPayment (elem) {
    $("#choosePaymentMethod").modal("hide");
    $("#test-info-card").hide();
    $("#pay-in-facility-card").show();
  }

  function goDefaultCodes() {
    $("#test-info-card").hide();
    $("#initiation-codes-card").show();
  }

  function onlinePayment(elem,total_amount,sub_total_amount) {
    var initiation_code = elem.getAttribute("data-initiation-code");
    
    swal({
      title: 'Continue?',
      text: "<p class='text-primary' id='num-tests-para'>Amount For Tests: ₦" + addCommas(total_amount) +".</p>" +
        "<p class='text-primary'>Vat: 7%</p>" +
        "<p class='text-primary'>Sub Total: ₦"+addCommas(sub_total_amount)+"</p>" +
       " Do Want To Continue To Payment?",
      type: 'success',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, proceed!'
    }).then((result) => {
      $(".spinner-overlay").show();
     window.location.assign("<?php echo site_url('onehealth/index/'.$addition.'/test_online_payment/') ?>"+initiation_code);
    }); 
    
  }

  function proceed1 (elem,evt) {
    var initiation_code = elem.getAttribute("data-initiation-code");
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/check_if_initiation_code_is_valid') ?>";
    
    // document.cookie = "initiation_code=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
    $(".spinner-overlay").show();
    var data = "code_valid=true&code="+initiation_code;
    // console.log(data);
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : data,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.invalid == true){
          swal({
            type: 'error',
            title: 'Oops.....',
            text: 'Sorry, Your Initiation Code Is Invalid!'
            // footer: '<a href>Why do I have this issue?</a>'
          })
        }else if(response.valid == true && response.total_amount !== 0 && response.test_num !== 0){
          var vat = 0.07 * response.total_amount;
          var total_amount = vat + response.total_amount;
          swal({
            title: 'Continue?',
            text: "<p class='text-primary' id='num-tests-para'>" + response.test_num + " tests selected with total sum of ₦" + addCommas(response.total_amount) +".</p>" + " Do Want To Continue To Payment?",
            type: 'success',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, proceed!'
          }).then((result) => {
            $("#choosePaymentMethod").modal("show");
            $("#online-payment-btn").attr("onclick","return onlinePayment(this,"+response.total_amount+","+total_amount+")");
            $("#online-payment-btn").attr("data-initiation-code",initiation_code);
            // $("#choosePaymentMethod").show();
          });   
        }else{
          swal({
            type: 'error',
            title: 'Oops.....',
            text: 'Sorry, Something Went Wrong'
            // footer: '<a href>Why do I have this issue?</a>'
          })
        }
      },
      error : function () {
        swal({
          type: 'error',
          title: 'Oops.....',
          text: 'Something Went Wrong Please Check Your Internet Connection!'
          // footer: '<a href>Why do I have this issue?</a>'
        })
      }
    });   
      
  }

  function loadPatientInitiationCodeTable (initiation_code,status) {

    if(initiation_code !== ""){

      var url = "<?php echo site_url('onehealth/index/'.$addition.'/load-patient-tests-info') ?>";
      var patient_name = $("#name").innerHTML;
      
      $(".spinner-overlay").show();
      var data = "load-patient-tests-info=true&code="+initiation_code+"&name="+patient_name;
      console.log(data);
      $.ajax({
        url : url,
        type : "POST",
        responseType : "text",
        dataType : "text",
        data : data,
        success : function (response) {
          console.log(response)
          $(".spinner-overlay").hide();
          if(response !== ""){
            if(response == "no test with this code"){
              swal({
                type: 'error',
                title: 'Oops.....',
                text: 'Sorry, no record with this initiation code. Please try again!'
                // footer: '<a href>Why do I have this issue?</a>'
              })
            }else{
              $("#initiation-codes-card").hide();
              $("#test-info-card-body").html("");

              $("#test-info-card-body").append('<button class="btn btn-info" data-initiation-code="'+initiation_code+'" onclick="proceed1(this,event)">Proceed</button>');
              // setCookie("initiation_code",initiation_code,0.1);
              $("#initiation-code").html(initiation_code);
              if(status == "new"){
                $("#test-info-card-body").append('<button class="btn btn-warning" onclick="goDefault()">Go Back</button>');
              }else if(status == "already"){
                $("#test-info-card-body").append('<button class="btn btn-warning" onclick="goDefaultCodes()">Go Back</button>');
              }

              $("#test-info-card-body").append(response);
              $("body").append("<span style='visibility : hidden;' id='initiation-code'>"+initiation_code+"</span>");
              $("#select-test-card").hide();
              $("#carryOutTransaction").modal("hide");
              $("#main-card").hide();
              $("#example").DataTable();
              $("#test-info-card").show();
              

              // example Search script in tfoot

              var table = $('#example').dataTable();
              // $('#example tfoot th').each(function (i)
              // {
              //   var title = $('#example thead th').eq($(this).index()).text();
              //   var serach = '<input type="text" placeholder="Search ' + title + '" />';
              //   $(this).html('');
              //   $(serach).appendTo(this).keyup(function () {
              //         table.fnFilter($(this).val(), i)

              //   });  
              // });
            }
          }
        },
        error : function (argument) {
          $(".spinner-overlay").hide();
           $.notify({
            message:"Sorry Something Went Wrong"
            },{
              type : "danger"  
            });
        }
      });  
    }
  }



  function loadPreviousTransactions(elem) {
    $("#carryOutTransaction").modal("hide");
    $("#main-card").hide();
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/get-initiation-codes') ?>";
    $(".spinner-overlay").show();
    $.ajax({
      url : url,
      type : "POST",
      responseType : "text",
      dataType : "text",
      data : "get-initiation-codes=true",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        $("#initiation-codes-card .card-body").append(response);
        var table = $("#initiation-codes-table").DataTable();
        $('#initiation-codes-table tbody').on('click', 'tr', function () {
            if ( $(this).hasClass('selected') ) {
                $(this).removeClass('selected');
            }
            else {
                table.$('tr.selected').removeClass('selected');
                $(this).addClass('selected');
            }
        } ); 
        $("#initiation-codes-card").show();

      },
      error : function () {
        $(".spinner-overlay").hide();
      }
    });  
  }

  function deleteTest (elem) {
    var td = elem.parentElement;
    var tr = td.parentElement;
    var tr_id = tr.getAttribute("id");
    var table = document.getElementById("example");
    console.log(tr_id);
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/remove-test') ?>"
    $(".spinner-overlay").show();
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "remove_test=true&id="+tr_id,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.values_messed == true){
          $.notify({
          message:"Please Do Not Mess With This Page"
          },{
            type : "warning"  
          });
        }else if (response.error == true) {
          $.notify({
          message:"Sorry something went wrong"
          },{
            type : "warning"  
          });
        }else if(response.success == true){
         tr.remove();
         // table.draw();
         var val = tr.querySelector(".test-cost").innerHTML;
         var old_total = document.getElementById("total-main").innerHTML;
        
         var new_total = old_total - val;
         document.getElementById("total-main").innerHTML = new_total;
         new_total = addCommas(new_total);

         document.getElementById("total-display").innerHTML = "₦ " + new_total;

        }
      },
      error : function () {
        $(".spinner-overlay").hide();
      }
    });  
  }

  function goDefault() {
    
    document.location.reload();
  }

  function openSelectTestsCard (elem) {
    
    submitPatientNameForm("registered_patient",'clinical-pathology');
  }

  function addCommas(nStr)
  {
      nStr += '';
      x = nStr.split('.');
      x1 = x[0];
      x2 = x.length > 1 ? '.' + x[1] : '';
      var rgx = /(\d+)(\d{3})/;
      while (rgx.test(x1)) {
          x1 = x1.replace(rgx, '$1' + ',' + '$2');
      }
      return x1 + x2;
  }

  function patientCheckBoxEvt() {
    var total = tests_selected_obj.length;
    // total += $('.tests-checkboxes:checkbox:hidden:checked').length;
    var sum = 0;
    // var selectedRows = client_table.rows({ selected: true }).length;
    for(var i = 0; i < tests_selected_obj.length; i++){
      var test_cost = tests_selected_obj[i]['test_cost'];
      sum += parseInt(test_cost);
    }
    if(total > 0){
      
      if(!$("#num-tests-para")){
        $("#welcome-heading").after("<p class='text-primary' id='num-tests-para'>" + total + " test selected with total sum of ₦" + addCommas(sum) + ".</p>");
      }else{
        $("#num-tests-para").remove();
        $("#welcome-heading").after("<p class='text-primary' id='num-tests-para'>" + total + " tests selected with total sum of ₦" + addCommas(sum) + ".</p>");
      }
    }else{
      $("#num-tests-para").html("");
    }
  }

  function proceed (status,patient_user_name,patient_name1) {

    patientCheckBoxEvt();
    
    var total = tests_selected_obj.length;
    console.log({data : tests_selected_obj});
    // console.log(JSON.stringify({data : tests_selected_obj}))
    // total += $('.tests-checkboxes:checkbox:hidden:checked').length;
    var sum = 0;
    // var selectedRows = client_table.rows({ selected: true }).length;
    var sub_dept_id = 0;
    
    for(var i = 0; i < tests_selected_obj.length; i++){
      var test_cost = tests_selected_obj[i]['test_cost'];
      sum += parseInt(test_cost);
    }
    

    if(total > 0){
      
      swal({
        title: 'Continue?',
        text: "<p class='text-primary' id='num-tests-para'>" + total + " tests selected with total sum of ₦" + addCommas(sum) + ".</p>" + " Do Want To Continue?",
        type: 'success',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, proceed!'
      }).then((result) => {
          var submit_tests_url = "<?php echo site_url('onehealth/index/'.$hospital_slug.'/pathology-laboratory-services/'.$sub_dept_slug.'/receptionist/submit_tests2') ?>";
          
          
          
          $(".spinner-overlay").show();
          $.ajax({
            url : submit_tests_url,
            type : "POST",
            responseType : "json",
            dataType : "json",
            data : {data : tests_selected_obj},
            success : function (response) {
              console.log(response)
             if(response.success && response.initiation_code != ""){
              $(".spinner-overlay").hide();
              swal({
                type: 'success',
                title: 'Successful',
                allowOutsideClick : false,
                allowEscapeKey :false,
                text: 'The Tests Have Been Added Successfully. Your initiation code is <b class="text-primary" style="font-style: italic; cursor : pointer;" onclick="copyText(\'' + response.initiation_code + '\')">' + response.initiation_code +'</b>. Click Initiation Code To Copy.'
                // footer: '<a href>Why do I have this issue?</a>'
              }).then((result) => {
                document.location.reload();
              });
             }
             else{
              $(".spinner-overlay").hide();
              swal({
                type: 'error',
                title: 'Oops.....',
                text: 'Sorry, something went wrong. Please try again!'
                // footer: '<a href>Why do I have this issue?</a>'
              })
             }
            },
            error : function(){
              $(".spinner-overlay").hide();
              swal({
                type: 'error',
                title: 'Oops.....',
                text: 'Sorry, something went wrong. Please try again!'
                // footer: '<a href>Why do I have this issue?</a>'
              })
            }
          })
          
      })
    }else{
      swal({
        type: 'error',
        title: 'Oops.....',
        text: 'Sorry, you have not selected any tests. Please Select To Continue'
        // footer: '<a href>Why do I have this issue?</a>'
      })
    }
    
  }

  function viewTestSubTests (elem,e,url) {
    
    $(".spinner-overlay").show();
    
    var tr = $(elem.parentElement.parentElement);
    var id = tr.find(".tests-checkboxes").attr("data-main-test-id");
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "test_id="+id+"&receptionist=true",
      success : function (response) {
        // console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true && response.messages != "" && response.test_name != ""){
          $(".spinner-overlay").hide();
          var messages = response.messages;
          var test_name = response.test_name;
          var card_header_str = "Sub Tests Of " + test_name;
          $("#sub-tests-card .card-title").html(card_header_str);
          $("#sub-tests-card .card-body").html(messages);

          $("#sub-tests-table").DataTable();
          $("#select-test-card").hide();
          
          $("#sub-tests-card").show();
        }
      },error : function (argument) {
        $(".spinner-overlay").hide();
      }
    });  
  }

  function submitPatientNameForm (status,sub_dept_slug) {
    var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?1234567890]/;
    if(status == "new_patient"){
      var patient_name = $("#patient-name").val();
    }else if(status == "registered_patient"){
      var patient_name = document.getElementById("name").innerHTML;
      var patient_user_name = document.getElementById("user_name").innerHTML;
    }
    var get_tests_url = "<?php echo site_url('onehealth/index/'.$hospital_slug.'/pathology-laboratory-services/get_all_facility_tests'); ?>";
    
    patient_name = $.trim(patient_name);
    
    
      if(format.test(patient_name)){
        $(".form-error").html("The Patient Name Field Cannot Contain Illegal Characters"); 
      }else{
        $(".spinner-overlay").show();

        $.ajax({
          url : get_tests_url,
          type : "POST",
          responseType : "json",
          dataType : "json",
          data : "type=mine",
          success : function (response) {
            $(".spinner-overlay").hide();
            var messages = response.messages;
            var user_name = $("#user_name").html();
            var patient_name = $("#name").html();
            console.log(response.messages);
            if(messages !== ""){  
             $("#main-card").hide();
              $("#select-test-card").show();
                 
              $("#select-test-card .card-header .proceed").attr('onclick' , "proceed('registered_patient','"+user_name+"','"+patient_name+"')")
              
              $("#select-test-card .card-body").html(messages);
              $("#select-test-card").show();
              
              $(".table").DataTable();
            }
          },
          error : function () {
            $(".spinner-overlay").hide();
            
            $.notify({
            message:"Sorry something went wrong"
            },{
              type : "danger"  
            });
          } 
         });    
       
      }
  } 
</script>
         <!-- End Navbar -->

       <div class="spinner-overlay" style="display: none;">
        <div class="spinner-well">
          <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading..." style="">
        </div>
      </div>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-12">
              <p id="initiation-code" style="display: none;"></p>
              <div class="card" id="test-info-card" style="display: none;">
                <div class="card-header">
                  <h2 class="card-title"><?php echo $hospital_name; ?></h2>
                </div>
                <div class="card-body" id="test-info-card-body">
                  
                </div>
              </div>
              <div class="card" id="main-card">
                <div class="card-header">
                  <h2 class="card-title"><?php echo $hospital_name; ?></h2>
                </div>
                <div class="card-body" style="margin-top: 50px;">
                  <button type="button" onclick="return openSelectTestsCard(this)" class="btn btn-primary">Select Tests</button>
                  <button class="btn btn-info btn-action" data-toggle="modal" data-target="#carryOutTransaction">Carry Out Transaction</button>
                  
                </div>
              </div>
              
              <div class="card" id="pay-in-facility-card" style="display: none;">
                <div class="card-header">
                  <h2 class="card-title">Pay In Health Facility</h2>
                </div>
                <div class="card-body">
                  <button class="btn btn-warning" onclick="goDefault()">Go Back</button>
                  <h5 class="text-secondary">Note: To Pay In Health Facilty, Copy Down Your Initiation Code And Proceed To The Health Facility Located At <span class="text-primary" style="font-style: italic;"><?php echo $hospital_address; ?></span>. Ask For The Teller And Give Him Your Initiation Code And Complete Payment.</h5>
                  
                </div>
              </div>

              <div class="card" id="select-test-card" style="display: none;">
                <div class="card-header">
                  <button onclick="goBackFromSelectTestsCard(this,event)" class="btn btn-warning">Go Back</button>
                  <button class="btn btn-info proceed">Proceed</button>
                  <h3 class="card-title">Select Required Tests</h3>
                </div>
                <div class="card-body">
                  
                  
                
                </div>
              </div>
              
              <div class="card" id="sub-tests-card" style="display: none;">
                <div class="card-header">
                  <h3 class="card-title" style="text-transform: capitalize;"></h3>
                  <button  type="button" class="btn btn-round btn-warning" onclick="goBackSubTests1()">Go Back</button>
                </div>
                <div class="card-body">
                  
                                    
                </div> 
              </div>
  

              <div class="card" id="initiation-codes-card" style="display: none;">
                <div class="card-header">
                  <h2 class="card-title"><?php echo $hospital_name; ?></h2>
                </div>
                <div class="card-body">
                   <h4>All Initiation Codes Generated By You</h4>           
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" data-backdrop="static" id="carryOutTransaction" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="carryOutTransaction" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title"><span class="text-secondary">Note: Code Is Case Sensitive</span></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="return goDefault()">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>


            <div class="modal-body" id="modal-body">
              <?php $attributes = array('class' => '','id' => 'initiation-code-form') ?>
              <?php echo form_open('',$attributes); ?>

                <div class="form-group">

                  <label for="initiation-code">Enter Initiation Code: </label>
                  <input type="text" id="initiation-code" class="form-control" name="initiation-code" required>
                  <span class="form-error"></span>
                </div>
                <input type="submit" class="btn btn-success" value="PROCEED" name="submit">
              <?php echo form_close(); ?>
              <span class="form-error">Cannot Remember Initiation Code?</span><br>
              <button class="btn btn-primary" onclick="loadPreviousTransactions(this)">Click Here</button>
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="return goDefault()">Close</button>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" data-backdrop="static" id="choosePaymentMethod" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="carryOutTransaction" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h3 class="modal-title"><span class="text-secondary">Choose Payment Method</span></h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>


            <div class="modal-body" id="modal-body">
              <p class="text-secondary">Note: Once Payment Is Completed Please Go To The Facility For Collection Of Sample.</p>
              <p>Facility Address: <?php echo $hospital_address; ?>. <span class="text-primary">Please Save It.</span></p>
              <?php
               if($this->onehealth_model->checkIfBankDetailsAreSet($hospital_name,$hospital_id)){ 
                ?>
              <button class="btn btn-primary" id="online-payment-btn" onclick="return onlinePayment(this)">Online Payment</button>
              <?php 
            } 
            ?>
              <button class="btn btn-info" onclick="return physicalPayment(this)">Pay In Health Facility</button>
              
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="return goDefault()">Close</button>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" data-backdrop="static" id="paymentSuccess" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="paymentSuccessful" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title"><span class="text-primary"></span></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>


            <div class="modal-body">
              
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
       
      <footer class="footer">
        <div class="container-fluid">
          <footer>&copy; <?php echo date("Y"); ?> Copyright (OneHealth Issues Global Limited). All Rights Reserved</footer>
          <?php
          $code_date = date("j");
          $code_time = date("h");
          $initiation_code = substr(bin2hex($this->encryption->create_key(8)),4). '-' . $code_date .'-' . $code_time;
        ?>
        <p id="var-dump" style="display: none;"><?php echo $initiation_code; ?></p>
        </div>
      </footer>
      <span style="display: none;" id="user_name"><?php echo $user_name; ?></span>
      <span style="display: none;" id="name"><?php echo $this->onehealth_model->getPatientName($patient_bio_data_table,$user_id,$user_name); ?></span>
      
      <script>
        $(document).ready(function() {
         
         
          $("#initiation-code-form").submit(function (evt) {
            evt.preventDefault();
            var initiation_code = $("#initiation-code-form #initiation-code").val();
            $("#no-record").remove();
            loadPatientInitiationCodeTable(initiation_code,"new");
          });
        <?php
         if($this->session->paid_successfully){ 
          unset($_SESSION['paid_successfully'])
          ?>
          $.notify({
          message:"Payment Successful. A Notification Has Been Sent To You. You Would Find Your Receipt Attached"
          },{
            type : "success"  
          });
        <?php } ?>
        <?php
         if($this->session->refundrequestapproved){ 
          unset($_SESSION['refundrequestapproved'])
          ?>
          $.notify({
          message:"Payment Has Been Refunded Successfully"
          },{
            type : "success"  
          });
        <?php } ?>  
        <?php
        if($this->session->refundrequestdeclined){ 
          unset($_SESSION['refundrequestdeclined'])
          ?>
          $.notify({
          message:"Refund Request Has Been Declined Successfully"
          },{
            type : "success"  
          });
        <?php } ?> 
        <?php
         if($this->session->error && $this->session->error == "wrong"){ 
          
          ?>
          $.notify({
          message:"Something Went Wrong. Please Check Your Internet Connection And Try Again"
          },{
            type : "warning"  
          });
        <?php } ?>  
        <?php
         if($this->session->error && $this->session->error == "invalid_code"){ 
          
          ?>
          $.notify({
          message:"Invalid Code Entered"
          },{
            type : "warning"  
          });
        <?php } ?>  
        <?php
        if($this->session->error && $this->session->error == "code_absent"){ 
          
          ?>
          $.notify({
          message:"Something Went Wrong"
          },{
            type : "danger"  
          });
        <?php } ?>  
      });
      </script>
    </div>
  </div>
<?php }  }?>
  <!--   Core JS Files   -->
 