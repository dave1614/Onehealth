<!DOCTYPE html>
<html>
<head>
	<title>onehealth</title>
	<meta charset="utf-8">
	<link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url('assets/images/logo.jpeg') ?>">
	<link rel="icon" type="image/png" href="<?php echo base_url('assets/images/logo.jpeg') ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<link rel="stylesheet" href="<?php echo base_url('assets/css/owl.carousel.min.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/owl.theme.default.css'); ?>">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
	<script src="<?php echo base_url('assets/js/jquery-3.0.0.js') ?>"></script>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/animate.css') ?>">
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	 <!-- <link rel="stylesheet" href="<?php echo base_url('assets/css/material-dashboard.min.css') ?>"> -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/styles.css'); ?>">
	<style>
		body{
			font-family: 'Quicksand', sans-serif;
		}
	</style>
</head>
<body>
	<div class="container-fluid" style="min-height: 500px;">
		<h2 style="margin-top: 30px;"><a href="index.php" style="color: black; " class="brand"><img style="width: 66px; border-radius: 50%;" src="<?php echo base_url('assets/images/logo.jpeg'); ?>" alt="One Health"></a></h2>
		<nav class="navbar navbar-default " style="background: #f8f8f8;">

			<div class="container-fluid">
			    <div class="navbar-header">
				    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span> 
                	</button>
				</div>
			</div>
			<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav navbar-right" style="margin: 2px auto;">
					<li><a href="" style="color: indianred; font-weight: 800;"  data-toggle="modal" data-target="#sign-in-modal">Sign Up | Login</a></li>
				</ul>
			</div>	
		</nav>

		<div class="row">
			<div class="" >
				<img src="<?php echo base_url('assets/images/logo.jpeg') ?>" class="col-sm-12 col-xs-12" style="height: 40%;" alt="">
			</div>
		</div>

		<div class="modal fade fadeInLeft" id="sign-in-modal" data-backdrop="static">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Choose Your Action?</h4>
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>

					<div class="modal-body" style="height: 100%;">
						<h3 id="modal-question">Do You Want To?</h3>
						<div class="button-container">
							<a class="btn button btn-default" id="sign-in-btn" href="<?php echo site_url('onehealth/sign_in') ?>">Sign In </a>
							<a class="btn button btn-info" id="sign-up-btn" onclick='sign_up_btn()'>Sign Up</a>
						</div>
						<?php $attributes = array('class' => '','id' => 'health-facility-name-form','style' => 'display:none;') ?>
						<?php echo form_open('onehealth/',$attributes); ?>
							<div class="form-group">
								<input type="text" id="health-facility-name" placeholder="Enter Health Facility Name" name="health-facility-name" class="form-control">
							</div>
							
						<?php echo form_close(); ?>

						
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
	</div>	
	<footer class="home-footer">
		<p>Copyright &copy; 2018. All Rights Reserved.</p>
	</footer>
</body>
<script>
	$(document).ready(function () {
		$("#health-facility-name-form").submit(function (evt) {
			evt.preventDefault();
		})
		
	})
	
	function sign_up_back_btn() {
		// console.log('sty');
			$("#modal-question").text("Do You Want To");
			$(".button-container a").remove();
			
			$(".button-container").html('<a class="btn button btn-default" onclick="sign_in_btn()" id="sign-in-btn">Sign In </a>' + '<a class="btn button btn-info" onclick="sign_up_btn()" id="sign-up-btn">Sign Up</a>')
			
			$("#sign-up-back-btn").remove();
	}

	function sign_in_btn(){
		$("#modal-question").hide();
		$(".button-container").hide();
		$("#health-facility-name-form").show();
	}

	function sign_up_btn(){
		$("#modal-question").text("Sign Up As");
		$('#sign-in-btn').remove();
		$('#sign-up-btn').remove();
		$(".modal-body").append('<button style="margin-bottom: -8px; margin-top:10px;" class="btn btn-warning" id="sign-up-back-btn" onclick="sign_up_back_btn()">Back</button>');
		$(".button-container").html("<a style='display:inline-block; margin-right:5px;'  href='<?php echo site_url('onehealth/sign_in_as_health_facility') ?>' class='btn btn-default'>" + 'Health Facility' +"</a>" + "<a href='<?php echo site_url('onehealth/sign_up_as_patient') ?>' style='display:inline-block;' class='btn btn-info'>" + 'Patient' +"</a>");
	}

</script>
<script src="<?php echo base_url('assets/js/jquery-3.0.0.js') ?>"></script>
<script src="<?php echo base_url('assets/js/owl.carousel.min.js') ?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-7834185622507344",
    enable_page_level_ads: true
  });
</script>
</html>