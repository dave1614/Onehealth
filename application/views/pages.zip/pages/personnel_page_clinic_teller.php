<style>
  tr{
    cursor: pointer;
  }
  body {
  
}

</style>
      <!-- End Navbar -->
      <?php
      if(is_array($curr_health_facility_arr)){
        foreach($curr_health_facility_arr as $row){
          $health_facility_id = $row->id;
          $health_facility_name = $row->name;
          $health_facility_logo = $row->logo;
          $health_facility_structure = $row->facility_structure;
          $health_facility_email = $row->email;
          $health_facility_phone = $row->phone;
          $health_facility_country = $this->onehealth_model->getCountryById($row->country);
          $health_facility_state = $this->onehealth_model->getStateById($row->state);
          $health_facility_address = $row->address;
          $health_facility_table_name = $row->table_name;
          $health_facility_date = $row->date;
          $health_facility_time = $row->time;
          $health_facility_slug = $row->slug;
          $color = $row->color;
        }
        $user_id = $this->onehealth_model->getUserIdWhenLoggedIn();
        $data_url_img = "<img style='display:none;' id='facility_img' width='100' height='100' class='round img-raised rounded-circle img-fluid' avatar='".$health_facility_name."' col='".$color."'>";
      }
    ?>
<script> 
  var selected_rows = [];
  function performFunctions (elem,evt) {
    $("#main-card").hide();
    $("#choose-action-card").show();
  }

  function goBackChooseAction (elem,evt) {
    $("#main-card").show();
    $("#choose-action-card").hide(); 
  }

  function goBackPayRegistrationFee(elem,evt) {
    $("#main-card").show();
    $("#register-patient-card").hide();
  }

  function goBackPatientHistoryInfoCard (elem,evt) {
    $("#payment-history-card").show();
    $("#payment-history-info-card").hide();
    
  }

  function submitRegistrationAmountForm (elem,evt,id,patient_name,hospital_number,receipt_number,receipt_file) {
    evt.preventDefault();
    // console.log(elem.serializeArray());
    swal({
      title: 'Warning?',
      text: "Do You Want To Mark This Patient As Paid?",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, proceed!'
    }).then((result) => {
      var registration_amt = elem.querySelector("#registration_amt").value;
      console.log(registration_amt);
      var health_facility_logo = $("#facility_img");
      var logo_src = health_facility_logo.attr("src");
      var logo_src_substr = logo_src.substring(0,4);
      if(logo_src_substr !== "data"){
        var img_data_url = $("#facility_img").attr("src");
        var company_logo = {
         src:img_data_url,
          w: 80,
          h: 50
        };
      }else{
        var img_data_url = $("#facility_img").attr("src");
        var company_logo = "";
      }
      $(".spinner-overlay").show();
          
      var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/mark_patient_as_paid'); ?>";
      
      $.ajax({
        url : url,
        type : "POST",
        responseType : "json",
        dataType : "json",
        data : "registration_amt="+registration_amt + "&id="+id+"&receipt_file="+receipt_file,
        success : function (response) {
          console.log(response)
          
          if(response.success == true){
            var patient_name = response.patient_name;
            var receipt_number = response.receipt_number;
            var facility_state = '<?php echo $health_facility_state; ?>';
            var facility_country = '<?php echo $health_facility_country; ?>';
            var facility_address = response.facility_address;
            var facility_name = '<?php echo $health_facility_name; ?>';
            var date = response.date;
            var hospital_number = response.hospital_number;
            var sum = response.sum;
            
            var pdf_data = {
              'logo' : company_logo,
              'color' : <?php echo $color; ?>,
              'sum' : sum,
              "patient_name" : patient_name,
              "receipt_number" : receipt_number,
              "facility_state" : facility_state,
              'facility_id' : "<?php echo $health_facility_id; ?>",
              "facility_country" : facility_country,
              "facility_name" : facility_name,
              "hospital_number" : hospital_number,
              "facility_address" : facility_address,
              "date" : date,
              'mod' : 'teller',
              "receipt_file" : receipt_file,
              "clinic" : true
            };

            var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/save_receipt_clinic') ?>";
            // var pdf = btoa(doc.output());
            $.ajax({
              url : url,
              type : "POST",
              responseType : "json",
              dataType : "json",
              data : pdf_data,
              
              success : function (response) {
                console.log(response)
                $(".spinner-overlay").hide();
                if(response.success == true){
                  var pdf_url = "<?php echo base_url('assets/images/'); ?>" + receipt_file;
                  window.location.assign(pdf_url);
                }else{
                  console.log('false')
                }
              },
              error : function () {
                $(".spinner-overlay").hide();
                
              }
            })
          }
          
        },
        error: function (jqXHR,textStatus,errorThrown) {
          $(".spinner-overlay").hide();
           $.notify({
            message:"Sorry Something Went Wrong"
            },{
              type : "danger"  
            });
          $(".form-error").html();
        }
      });

    })
    
  }

  function markAsPaid(elem,evt,id) {
    evt.preventDefault();
    var tr = elem.parentElement.parentElement;
    var patient_name = tr.getAttribute("data-name");
    var hospital_number = tr.getAttribute("data-hospital-num");
    var receipt_number = tr.getAttribute("data-receipt-number");
    var receipt_file = tr.getAttribute("data-receipt-file");
    $("#mark-paid-patients-modal .modal-title").html("Mark " + patient_name +" As Paid");
    document.querySelector("#mark-paid-patients-modal .modal-body #registration-amount-form").setAttribute(`onsubmit`,`submitRegistrationAmountForm(this,event,'${id}','${patient_name}','${hospital_number}','${receipt_number}','${receipt_file}')`);
    $("#mark-paid-patients-modal").modal("show");
  }

  function collectRegistrationFee (elem,evt) {
    
    evt.preventDefault();
    $(".spinner-overlay").show();
          
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/view-registered-patients-records-unpaid'); ?>";
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true){
          $("#register-patient-card .card-body").html(response.messages);

          $("#choose-action-card").hide();
          $("#register-patient-card").show();
          $("#registered-patients-unpaid-table").DataTable();
        }else if(response.nodata = true){
          swal({
            title: 'Sorry',
            text: "<p>You Have No Records To Display Here</p>",
            type: 'warning'
          }).then((result) => {
            // document.location.reload();
          })
        }
        else{
         $.notify({
          message:"Sorry Something Went Wrong"
          },{
            type : "danger"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong. Please Check Your Internet Connection And Try Again"
        },{
          type : "danger"  
        });
      }
    });
  }

  function goBackOwingPatientsWards (elem,evt) {
    $("#choose-action-card").show();
    $("#owing-patients-wards-card").hide();
    
  }

  function goBackPayOwingPatientsWards (elem,evt) {
    var str = "";
    $("#owing-patients-wards-card").show();
    $("#pay-owing-patients-wards-form").attr("data-id","");
    $("#pay-owing-patients-wards-form #ward-payment-info").html(str);
    $("#pay-owing-patients-wards-form #amount").val("");
    $("#pay-owing-patients-wards-card").hide();
  }

  function goBackOustandingBillsCard (elem,evt) {
    
    $("#choose-action-card").show();
    $("#outstanding-bills-card").hide();
    
  }

  function goBackPatientsOustandingBillsCard (elem,evt) {
    $("#outstanding-bills-card").show();
    $("#patients-outstanding-bills-card").hide();
    $("#proceed-bills-selection-btn").hide("fast");
  }

  function goBackPatientHistoryCard (elem,evt) {
    $("#choose-action-card").show();
    $("#payment-history-card").hide();
    
  }

  function checkAll(elem,evt){
    elem = $(elem);
    selected_rows = [];
    if(elem.prop('checked')){
      console.log(elem.parents("table").find('tbody input[type=checkbox]').length);
      elem.parents("table").find('tbody input[type=checkbox]').each(function(index, el) {
        var el = elem.parents("table").find('tbody input[type=checkbox]').eq(index);
        el.prop('checked', true);
        var id = el.attr("data-id");
        var amount = el.attr("data-amount");
        var data = {
          "id" : id,
          "amount" : amount
        };
        selected_rows.push(data);
      });
    }else{
      elem.parents("table").find('tbody input[type=checkbox]').each(function(index, el) {
        var el = elem.parents("table").find('tbody input[type=checkbox]').eq(index);
        el.prop('checked', false);
      });  
    }
  }

  function addCommas(nStr)
  {
      nStr += '';
      x = nStr.split('.');
      x1 = x[0];
      x2 = x.length > 1 ? '.' + x[1] : '';
      var rgx = /(\d+)(\d{3})/;
      while (rgx.test(x1)) {
          x1 = x1.replace(rgx, '$1' + ',' + '$2');
      }
      return x1 + x2;
  }

  function proceedBillsSelection(elem,evt) {
    var health_facility_logo = $("#facility_img");
    var logo_src = health_facility_logo.attr("src");
    var logo_src_substr = logo_src.substring(0,4);
    if(logo_src_substr !== "data"){
      var img_data_url = $("#facility_img").attr("src");
      var company_logo = {
       src:img_data_url,
        w: 80,
        h: 50
      };
    }else{
      var img_data_url = $("#facility_img").attr("src");
      var company_logo = "";
    }
    console.log(selected_rows)
    var num = selected_rows.length;
    if(num > 0){
      var sum = 0.0;
      var id_arr = [];
      for(var i = 0; i < num; i++){
        var amount = parseFloat(selected_rows[i].amount);
        sum += amount;
        sum = Math.round(sum * 1e12) / 1e12;
        id = selected_rows[i].id;
        id_arr.push(id);
      }
      
      swal({
        title: 'Success',
        text: "<p><span class='text-primary' style='font-style: italic;'>"+num +"</span> Records Selected With Total Sum Of "+"<span class='text-primary' style='font-style: italic;'>"+sum+"</span>. Are You Sure You Want To Mark As Paid?</p>",
        type: 'success',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Proceed',
        cancelButtonText : "No"
      }).then(function(){
        if(id_arr != []){
          $(".spinner-overlay").show();
          
          var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/mark_clinic_patient_outstanding_as_paid'); ?>";
          $.ajax({
            url : url,
            type : "POST",
            responseType : "json",
            dataType : "json",
            data : {
              "ids" : id_arr
            },
            success : function (response) {
              console.log(response)
              $(".spinner-overlay").hide();
              if(response.success){
                var receipt_file = response.receipt_file;
                var patient_name = response.patient_name;
                var receipt_number = response.receipt_number;
                var facility_state = '<?php echo $health_facility_state; ?>';
                var facility_country = '<?php echo $health_facility_country; ?>';
                var facility_address = response.facility_address;
                var facility_name = '<?php echo $health_facility_name; ?>';
                var date = response.date;
                var hospital_number = response.hospital_number;
                var sum = response.sum;
                var balance = response.balance;
                
                var pdf_data = {
                  'balance' : balance,
                  'logo' : company_logo,
                  'color' : <?php echo $color; ?>,
                  'sum' : sum,
                  "patient_name" : patient_name,
                  "receipt_number" : receipt_number,
                  "facility_state" : facility_state,
                  'facility_id' : "<?php echo $health_facility_id; ?>",
                  "facility_country" : facility_country,
                  "facility_name" : facility_name,
                  "hospital_number" : hospital_number,
                  "facility_address" : facility_address,
                  "date" : date,
                  'mod' : 'teller',
                  "receipt_file" : receipt_file,
                  "clinic" : true
                };
                $(".spinner-overlay").show();
                var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/save_receipt_clinic') ?>";
                $.ajax({
                  url : url,
                  type : "POST",
                  responseType : "json",
                  dataType : "json",
                  data : pdf_data,
                  
                  success : function (response) {
                    console.log(response)
                    $(".spinner-overlay").hide();
                    if(response.success == true){
                      var pdf_url = "<?php echo base_url('assets/images/'); ?>" + receipt_file;
                      window.location.assign(pdf_url);
                    }else{
                      console.log('false')
                    }
                  },
                  error : function () {
                    $(".spinner-overlay").hide();
                    
                  }
                })
              }
              else{
               $.notify({
                message:"Sorry Something Went Wrong"
                },{
                  type : "danger"  
                });
              }
            },
            error: function (jqXHR,textStatus,errorThrown) {
              $(".spinner-overlay").hide();
              $.notify({
              message:"Sorry Something Went Wrong."
              },{
                type : "danger"  
              });
            }
          });
        }
      });
    }else{
      swal({
        title: 'Error',
        text: "At Least One CheckBox Must Be Selected To Proceed",
        type: 'error'
      })
    }
  }

  function checkBoxEvt (elem,evt) {
    elem = $(elem);
    var id = elem.attr("data-id");
    var amount = elem.attr("data-amount");
    var data = {
      "id" : id,
      "amount" : amount
    };
    var isChecked = false;

    if(elem.prop('checked')){
      isChecked = true;
    }

    if(isChecked){
      selected_rows.push(data);
    }else{
      var index = selected_rows.map(function(obj, index) {
          if(obj.id === id) {
              return index;
          }
      }).filter(isFinite);
      if(index > -1){
        selected_rows.splice(index, 1);
      }
    }

    // console.log(selected_rows)


  }

  function viewOutstandingPayments(elem,evt,patient_id){
    $(".spinner-overlay").show();
          
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_clinic_patient_outstanding_bills'); ?>";
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&patient_id="+patient_id,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true){
          $("#patients-outstanding-bills-card .card-body").html(response.messages);

          $("#outstanding-bills-card").hide();
          $("#patients-outstanding-bills-card").show();
          $("#patients-outstanding-bills-table").DataTable({
            "paging":   false,
            "info":     false
          });
          $("#proceed-bills-selection-btn").show("fast");
        }else if(response.nodata = true){
          swal({
            title: 'Sorry',
            text: "<p>You Have No Records To Display Here</p>",
            type: 'warning'
          }).then((result) => {
            // document.location.reload();
          })
        }
        else{
         $.notify({
          message:"Sorry Something Went Wrong"
          },{
            type : "danger"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong."
        },{
          type : "danger"  
        });
      }
    });
  }

  function collectOutstandingBills (elem,evt) {
    $(".spinner-overlay").show();
          
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_clinic_patients_outstanding_bills'); ?>";
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true){
          $("#outstanding-bills-card .card-body").html(response.messages);

          $("#choose-action-card").hide();
          $("#outstanding-bills-card").show();
          $("#outstanding-bills-table").DataTable();
        }else if(response.nodata = true){
          swal({
            title: 'Sorry',
            text: "<p>You Have No Records To Display Here</p>",
            type: 'warning'
          }).then((result) => {
            // document.location.reload();
          })
        }
        else{
         $.notify({
          message:"Sorry Something Went Wrong"
          },{
            type : "danger"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong."
        },{
          type : "danger"  
        });
      }
    });
  }

  function payAdmissionFee(elem,evt,id,admission_fee,no_of_days,grace_days,expiry_date){
    swal({
      title: 'Choose Action',
      text: "Choose Payment Option: ",
      type: 'success',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Pay Now',
      cancelButtonText : "Pay Later"
    }).then(function(){
      var str = "<h4>Ward Admission Fee: "+admission_fee+" For "+no_of_days+" Days With "+grace_days+" Days As Grace.</h4>";

      $("#owing-patients-wards-card").hide();
      $("#pay-owing-patients-wards-form").attr("data-id",id);
      $("#pay-owing-patients-wards-form #ward-payment-info").html(str);
      $("#pay-owing-patients-wards-form #amount").val(admission_fee);
      $("#pay-owing-patients-wards-card").show();
    },function(dismiss){
      if(dismiss == 'cancel'){
        swal({
          title: 'Warning',
          text: "Are You Sure You Want To Proceed",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ok',
          cancelButtonText : "Cancel"
        }).then(function(){
          var amount = 0;
          var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/pay_owing_patient_admission'); ?>";
          $(".spinner-overlay").show();
          $.ajax({
            url : url,
            type : "POST",
            responseType : "json",
            dataType : "json",
            data : "id="+id+"&amount=56&type=pay_later",
            success : function (response) {
              console.log(response)
              $(".spinner-overlay").hide();
              if(response.success){
                document.location.reload();
              }else{
                $.notify({
                message:"Sorry Something Went Wrong"
                },{
                  type : "warning"  
                });
              }
            },error : function () {
              $(".spinner-overlay").hide();
              swal({
                title: 'Ooops',
                text: "Something Went Wrong",
                type: 'error'
              })
            }  
          });  
        });
      }
    }) 
  }

  function collectAdmissionFee (elem,evt) {
    $(".spinner-overlay").show();
          
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/get_ward_patients_owing_admission_fee'); ?>";
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true){
          $("#owing-patients-wards-card .card-body").html(response.messages);

          $("#choose-action-card").hide();
          $("#owing-patients-wards-card").show();
          $("#owing-patients-table").DataTable();
        }else if(response.nodata = true){
          swal({
            title: 'Sorry',
            text: "<p>You Have No Records To Display Here</p>",
            type: 'warning'
          }).then((result) => {
            // document.location.reload();
          })
        }
        else{
         $.notify({
          message:"Sorry Something Went Wrong"
          },{
            type : "danger"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong."
        },{
          type : "danger"  
        });
      }
    });
  }

  function viewPaymentHistory (elem,evt) {
    $(".spinner-overlay").show();
          
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/view_clinic_payment_history'); ?>";
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true",
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true){
          $("#payment-history-card .card-body").html(response.messages);

          $("#choose-action-card").hide();
          $("#payment-history-card").show();
          $("#payment-history-table").DataTable();
        }
        else{
         $.notify({
          message:"Sorry Something Went Wrong"
          },{
            type : "danger"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong."
        },{
          type : "danger"  
        });
      }
    });
  }

  function loadPaymentsForDate(elem,evt,date) {
    console.log(date);

    $(".spinner-overlay").show();
          
    var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/load_clinic_payment_history_by_day'); ?>";
    $.ajax({
      url : url,
      type : "POST",
      responseType : "json",
      dataType : "json",
      data : "show_records=true&date="+date,
      success : function (response) {
        console.log(response)
        $(".spinner-overlay").hide();
        if(response.success == true){
          $("#payment-history-info-card .card-title").html("Payments Made On " + date);
          $("#payment-history-info-card .card-body").html(response.messages);
          $("#payment-history-card").hide();
          $("#payment-history-info-card").show();
          $("#payment-history-info-table").DataTable();
        }
        else{
         $.notify({
          message:"Sorry Something Went Wrong"
          },{
            type : "danger"  
          });
        }
      },
      error: function (jqXHR,textStatus,errorThrown) {
        $(".spinner-overlay").hide();
        $.notify({
        message:"Sorry Something Went Wrong."
        },{
          type : "danger"  
        });
      }
    });
  }
</script>    
      <div class="spinner-overlay" style="display: none;">
        <div class="spinner-well">
          <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
        </div>
      </div>
     
      <div class="content" tabindex="-1">
        <div class="container-fluid">
         <h2 class="text-center"><?php echo $health_facility_name; ?></h2>
          <?php
            $logged_in_user_name = $user_name;
            $user_position = $this->onehealth_model->getUserPosition($health_facility_table_name,$user_id);
            $personnel_info = $this->onehealth_model->getPersonnelBySlug($fourth_addition);
            if(is_array($personnel_info)){
              
              foreach($personnel_info as $personnel){
                $personnel_id = $personnel->id;
                $spersonnel_dept_name = $personnel->name;
                $personnel_slug = $personnel->slug;
                $personnel_sub_dept = $personnel->sub_dept_id;
                $personnel_num = $this->onehealth_model->getPersonnelNum($health_facility_table_name,$second_addition,$third_addition,$personnel_slug);
                
                  $health_facility_table_info = $this->onehealth_model->getHealthFacilityTableBySubDeptDeptAndPosition($health_facility_table_name,$second_addition,$third_addition,$fourth_addition);
                  if(is_array($health_facility_table_info)){
                    foreach($health_facility_table_info as $user){
                      $personnel_user_name = $user->user_name;
                      $user_name_slug = url_title($personnel_user_name);
                    }
                  }
                
              }
            }
          ?>
          <?php
           if(is_null($health_facility_logo)){
            echo $data_url_img; 
           }else{ 
            ?> 
          <img src="<?php echo base_url('assets/images/'.$health_facility_logo); ?>" style="display: none;" alt="" id="facility_img">
          <?php } ?>
          <?php

           if($this->onehealth_model->checkIfUserIsATopAdmin2($health_facility_table_name,$user_id)){ ?>
          <span style="text-transform: capitalize; font-size: 13px;" ><a class="text-info" href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/admin') ?>"><?php echo $dept_name; ?></a>&nbsp;&nbsp; > >  <a href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/'.$third_addition.'/admin') ?>" class="text-info"><?php echo $sub_dept_name; ?></a> &nbsp;&nbsp; > > <?php echo $personnel_name; ?></span>
          <?php  } elseif($user_position == "sub_admin"){ ?>
           <span style="text-transform: capitalize; font-size: 13px;" ><a href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/'.$sub_dept_slug.'/admin') ?>" class="text-info"><?php echo $sub_dept_name; ?></a> &nbsp;&nbsp; > > <?php echo $personnel_name; ?></span>
          <?php  } ?>
          <h3 class="text-center" style="text-transform: capitalize;"><?php echo $personnel_name; ?></h3>
          <?php if($user_position == "admin" || $user_position == "sub_admin"){ ?>
            <?php if($personnel_num > 0){ ?>
          <h4>No. Of Personnel: <a href="<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/personnel') ?>"><?php echo $personnel_num; ?></a></h4>
        <?php } ?>
          <?php } ?> 
          <div class="row">
            <div class="col-sm-12">

              <div class="card" id="main-card">
                <div class="card-header">
                  
                </div>
                <div class="card-body">
                  <h4 style="margin-bottom: 70px;" id="quest">Choose Action: </h4>
                  <button onclick="performFunctions(this,event)" class="btn btn-primary">Perform Functions</button>
                </div>
              </div>

              <div class="card" id="register-patient-card" style="display: none;">
                <div class="card-header">
                  <h3 class="card-title" id="welcome-heading">Welcome <?php echo $logged_in_user_name; ?></h3>
                </div>
                <div class="card-body">
                  <button onclick="goBackPayRegistrationFee(this,event)" class="btn btn-warning">Go Back</button>

                  <h4 style="margin-bottom: 40px;" id="quest">Registered Patients With Payment Pending</h4>
                  
                </div>
              </div>


              <div class="card" id="choose-action-card" style="display: none;">
                <div class="card-header">
                  <button class="btn btn-warning" onclick="goBackChooseAction(this,event)">Go Back</button>
                  <h4 class="card-title">Choose Action: </h4>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
      
                      <table class="table table-striped table-bordered  nowrap hover display" id="select-options-table-2" cellspacing="0" width="100%" style="width:100%">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Option</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>1</td>
                            <td onclick="collectRegistrationFee(this,event)">Collect Registration Fee</td>
                          </tr>
                          <tr>
                            <td>2</td>
                            <td onclick="collectOutstandingBills(this,event)">Collect Outstanding Bills</td>
                          </tr>
                          <tr>
                            <td>3</td>
                            <td onclick="collectAdmissionFee(this,event)">Collect Wards Admission Fee</td>
                          </tr>
                          <tr>
                            <td>4</td>
                            <td onclick="viewPaymentHistory(this,event)">View Payment History</td>
                          </tr>
                          
                        </tbody>
                      </table>
                  </div>
                </div>
              </div>

              <div class="card" id="owing-patients-wards-card" style="display: none;">
                <div class="card-header">
                  <button onclick="goBackOwingPatientsWards(this,event)" class="btn btn-warning">Go Back</button>
                  <h3 class="card-title">All Patients Owing Admission Fees</h3>
                </div>
                <div class="card-body">
                  
                </div>
              </div>

              <div class="card" id="outstanding-bills-card" style="display: none;">
                <div class="card-header">
                  <button onclick="goBackOustandingBillsCard(this,event)" class="btn btn-warning">Go Back</button>
                  <h3 class="card-title">All Patients With Oustanding Bills</h3>
                </div>
                <div class="card-body">
                  
                </div>
              </div>

              <div class="card" id="patients-outstanding-bills-card" style="display: none;">
                <div class="card-header">
                  <button onclick="goBackPatientsOustandingBillsCard(this,event)" class="btn btn-warning">Go Back</button>
                  <h3 class="card-title">Patients Oustanding Bills</h3>
                </div>
                <div class="card-body">
                  
                </div>
              </div>

              

              <div class="card" id="payment-history-card" style="display: none;">
                <div class="card-header">
                  <button onclick="goBackPatientHistoryCard(this,event)" class="btn btn-warning">Go Back</button>
                  <h3 class="card-title">Payment History</h3>
                </div>
                <div class="card-body">
                  
                </div>
              </div>

              <div class="card" id="payment-history-info-card" style="display: none;">
                <div class="card-header">
                  <button onclick="goBackPatientHistoryInfoCard(this,event)" class="btn btn-warning">Go Back</button>
                  <h3 class="card-title">Payment History</h3>
                </div>
                <div class="card-body">
                  
                </div>
              </div>


              <div class="card" id="pay-owing-patients-wards-card" style="display: none;">
                <div class="card-header">
                  <button onclick="goBackPayOwingPatientsWards(this,event)" class="btn btn-warning">Go Back</button>
                  <h3 class="card-title">Enter Amount To Pay</h3>
                </div>
                <div class="card-body">
                  <?php  
                    $attr = array('id' => 'pay-owing-patients-wards-form');
                    echo form_open('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/pay_owing_patient_admission',$attr);
                  ?>

                  <div id="ward-payment-info" style="margin-bottom: 50px;"></div>
                  <div class="form-group">
                    <label for="amount">Amount: </label>
                    <input type="number" class="form-control" id="amount" name="amount" >
                  </div>

                  <input type="submit" class="btn btn-primary">

                  </form>
                </div>
              </div>

            </div>
          </div>
          <div id="proceed-bills-selection-btn" onclick="proceedBillsSelection(this,event)" rel="tooltip" data-toggle="modal" data-toggle="tooltip" title="Proceed" style="background: #9c27b0; cursor: pointer; position: fixed; bottom: 0; right: 0;  border-radius: 50%; cursor: pointer; display: none; fill: #fff; height: 56px; outline: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
            <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
              <i class="material-icons" style="font-size: 25px; font-weight: normal; color: #fff;" aria-hidden="true">arrow_forward</i>

            </div>
          </div>
        </div>
      </div>
      
      </div>
      <footer class="footer">
        <div class="container-fluid">
           <footer>&copy; <?php echo date("Y"); ?> Copyright (OneHealth Issues Global Limited). All Rights Reserved</footer>
        </div>
       
      </footer>
  </div>


  <div class="modal fade" data-backdrop="static" id="mark-paid-patients-modal" data-focus="true" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Mark This Patient As Paid</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
          <span aria-hidden="true">&times;</span>
        </button>
      </div>


      <div class="modal-body" id="modal-body">
        <?php
          $attr = array('id' => 'registration-amount-form');
         echo form_open('',$attr);
        ?>
          <div class="form-group">
            <label for="registration_amt">Enter Registration Price</label>
            <input type="number" name="registration_amt" id="registration_amt" class="form-control">
            <span class="form-error"></span>
          </div>
          <input type="submit" class="btn btn-success" value="PROCEED">

        </form>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
      </div>
    </div>
  </div>
  
</body>
<script>
    $(document).ready(function() {
      $("#pay-owing-patients-wards-form").submit(function(evt) {
        evt.preventDefault();
        var health_facility_logo = $("#facility_img");
        var logo_src = health_facility_logo.attr("src");
        var logo_src_substr = logo_src.substring(0,4);
        if(logo_src_substr !== "data"){
          var img_data_url = $("#facility_img").attr("src");
          var company_logo = {
           src:img_data_url,
            w: 80,
            h: 50
          };
        }else{
          var img_data_url = $("#facility_img").attr("src");
          var company_logo = "";
        }
        var me  = $(this);
        var url = me.attr("action");
        var form_data = me.serializeArray();
        
        var id = me.attr("data-id");
        form_data = form_data.concat({
          "name" : "id",
          "value" : id
        })

        form_data = form_data.concat({
          "name" : "type",
          "value" : "normal"
        })

        console.log(url)
        console.log(form_data)
        $(".spinner-overlay").show();
        $.ajax({
          url : url,
          type : "POST",
          responseType : "json",
          dataType : "json",
          data : form_data,
          success : function (response) {
            console.log(response)
            $(".spinner-overlay").hide();
            if(response.success){
              var receipt_file = response.receipt_file;
              var patient_name = response.patient_name;
              var receipt_number = response.receipt_number;
              var facility_state = '<?php echo $health_facility_state; ?>';
              var facility_country = '<?php echo $health_facility_country; ?>';
              var facility_address = response.facility_address;
              var facility_name = '<?php echo $health_facility_name; ?>';
              var date = response.date;
              var hospital_number = response.hospital_number;
              var sum = response.sum;
              var balance = response.balance;
              
              var pdf_data = {
                'balance' : balance,
                'logo' : company_logo,
                'color' : <?php echo $color; ?>,
                'sum' : sum,
                "patient_name" : patient_name,
                "receipt_number" : receipt_number,
                "facility_state" : facility_state,
                'facility_id' : "<?php echo $health_facility_id; ?>",
                "facility_country" : facility_country,
                "facility_name" : facility_name,
                "hospital_number" : hospital_number,
                "facility_address" : facility_address,
                "date" : date,
                'mod' : 'teller',
                "receipt_file" : receipt_file,
                "clinic" : true
              };
              $(".spinner-overlay").show();
              var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/'.$fourth_addition.'/save_receipt_clinic') ?>";
              $.ajax({
                url : url,
                type : "POST",
                responseType : "json",
                dataType : "json",
                data : pdf_data,
                
                success : function (response) {
                  console.log(response)
                  $(".spinner-overlay").hide();
                  if(response.success == true){
                    var pdf_url = "<?php echo base_url('assets/images/'); ?>" + receipt_file;
                    window.location.assign(pdf_url);
                  }else{
                    console.log('false')
                  }
                },
                error : function () {
                  $(".spinner-overlay").hide();
                  
                }
              })
            }else if(response.amount_too_big && response.admission_fee != ""){
              $.notify({
              message:"The Amount Entered Is Too Large. Admission Fee Is "+response.admission_fee
              },{
                type : "warning"  
              });
            }
          },error : function () {
            $(".spinner-overlay").hide();
            swal({
              title: 'Ooops',
              text: "Something Went Wrong",
              type: 'error'
            })
          } 
        }); 
         
      });

      <?php if($this->session->admission_pay_later_successful){ ?>
       $.notify({
        message:"Patient Bill Has Been Successfully Added To His Outstanding Bills"
        },{
          type : "success"  
        });
     <?php } ?>
      
    });


</script>
