    <?php
      if(is_array($curr_health_facility_arr)){
        foreach($curr_health_facility_arr as $row){
          $health_facility_name = $row->name;
          $health_facility_logo = $row->logo;
          $health_facility_structure = $row->facility_structure;
          $health_facility_email = $row->email;
          $health_facility_phone = $row->phone;
          $health_facility_country = $row->country;
          $health_facility_state = $row->state;
          $health_facility_address = $row->address;
          $health_facility_table_name = $row->table_name;
          $health_facility_date = $row->date;
          $health_facility_time = $row->time;
          $health_facility_slug = $row->slug;
        }
      }
    ?>

    <script>
      function deleteSubAdmin(elem,evt,user_id){
        evt.preventDefault();
        swal({
            title: 'Warning',
            html: "Are You Sure You Want To Delete This SubAdmin?",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
            cancelButtonText : "No"
        }).then(function(){
          var url = "<?php echo site_url('onehealth/index/'.$addition.'/'.$second_addition.'/'.$third_addition.'/delete_sub_admin') ?>";
         
          $(".spinner-overlay").show();
          $.ajax({
            url : url,
            type : "POST",
            responseType : "json",
            dataType : "json",
            data : "id="+user_id,
            success : function (response) {
              console.log(response)
              $(".spinner-overlay").hide();
              if(response.unwarranted_access){
                $.notify({
                  message:"Sorry You Do Not Have Access Here."
                  },{
                    type : "warning" 
                });
              }
              else if(response.success){
                document.location.reload();
              }else{
                $.notify({
                  message:"Sorry Something Went Wrong."
                  },{
                    type : "warning" 
                });
              }
            },error : function () {
              $(".spinner-overlay").hide();
              $.notify({
                message:"Sorry Something Went Wrong. Please Check Your Internet Connection"
                },{
                  type : "danger" 
              });
            } 
          }); 
        });
      }
    </script>
  
      <!-- End Navbar -->
      <div class="spinner-overlay" style="display: none;">
        <div class="spinner-well">
          <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
        </div>
      </div>
      <div class="content">
        <div class="container-fluid">
          <h2 class="text-center"><?php echo $health_facility_name; ?></h2>
          <h3>Welcome <?php echo $user_name; ?></h3>
          <?php
            $depts_arr = $this->onehealth_model->getDeptById($dept_id);
            if(is_array($depts_arr)){
              foreach($depts_arr as $dept){
                $dept_name = $dept->name;
                $dept_slug = $dept->slug;        
              } 
              $sub_dept_info = $this->onehealth_model->getSubDeptBySlug($third_addition);
              if(is_array($sub_dept_info)){
                foreach($sub_dept_info as $sub_dept){
                  $sub_dept_id = $sub_dept->id;
                  $sub_dept_name = $sub_dept->name;
                  $sub_dept_slug = $sub_dept->slug;
                   if($this->onehealth_model->getHealthFacilityTableByDeptAndPosition($health_facility_table_name,$dept_slug,$sub_dept_slug) !== false){
                    $health_facility_table_info = $this->onehealth_model->getHealthFacilityTableByDeptAndPosition($health_facility_table_name,$dept_slug,$sub_dept_slug);
                    if(is_array($health_facility_table_info)){
                      foreach($health_facility_table_info as $user){
                        $user_name = $user->user_name;
                        $user_name_slug = url_title($user_name);
                      }
                      $sub_admins_num = $this->onehealth_model->getSubAdminsNum($health_facility_table_name,$dept_slug,$sub_dept_slug);
                    }
                  }
                }
              }  
            }
          ?>
         
          <span style="text-transform: capitalize; font-size: 13px;" ><a class="text-info" href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/admin') ?>"><?php echo $dept_name; ?></a>&nbsp;&nbsp; > >  <?php echo $sub_dept_name; ?> </span>
          
          <h3 style="text-transform: capitalize;" class="text-center"><?php echo $sub_dept_name; ?></h3>
          <?php if($no_admin == false){ ?>
          <?php   if($sub_admins_num  == 1){ ?>
          <h4>Admin: <a href="<?php echo site_url('onehealth/'.$user_name_slug) ?>"><?php echo $user_name; ?></a></h4>
          <?php   }else{?>
          <h4><a><?php echo $sub_admins_num; ?></a> Sub Admins: &nbsp;&nbsp;</h4>
          
          <?php   } ?>  
          <?php } ?>  
          <div class="row">
            <div class="col-sm-8">
              <div class="card">
                <div class="card-header card-header-blue card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons">assignment</i>
                  </div>
                  <div class="card-title">
                    <h4 style="text-transform: capitalize;"><?php echo $sub_dept_name; ?>'s SubAdmins</h4>
                  </div>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th class="text-center">#</th>
                          <th>Sub-Admin Username</th>
                          <th>Date Registered</th>
                          <th class="text-right">Actions</th>
                        </tr>
                      </thead>

                      <tbody>
                        <?php
                        $num = 0;
                          if(is_array($sub_admins)){

                            foreach($sub_admins as $sub_admin){
                              $sub_admin_name = $sub_admin->user_name;
                              $sub_admin_user_id = $sub_admin->user_id;
                              $sub_admin_slug = strtolower(url_title($sub_admin_name));
                              $date = $sub_admin->date;
                              $time = $sub_admin->time;
                              $num++;
                        ?>
                        <tr>
                          <td><?php echo $num; ?></td>
                          <td style="text-transform: capitalize;"><a class="text-primary" href="<?php echo site_url('onehealth/'.$sub_admin_slug); ?>"><?php echo $sub_admin_name; ?></a></td>
                         <td class="text-secondary"><?php echo $date . ' at ' . $time; ?></td>
                          
                          <td class="td-actions text-right">
                            <a href="" rel="tooltip" data-toggle="tooltip" onclick="deleteSubAdmin(this,event,<?php echo $sub_admin_user_id; ?>)" title="Delete SubAdmin" class="btn btn-danger">
                              <i class="fas fa-user-times"></i>
                            </a>
                              
                             

                             
                          </td>

                         
                        </tr>
                        <?php      
                            }
                          }
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
           <footer>&copy; <?php echo date("Y"); ?> Copyright (OneHealth Issues Global Limited). All Rights Reserved</footer>
        </div>
      </footer>
  </div>
  
  
</body>
<script>
    $(document).ready(function() {
      
      <?php
        if($no_admin == true){
      ?>
        swal({
          title: 'Warning?',
          text: "You do not currently have any admin in this section. Dou Want To Add One?",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, add!'
        }).then((result) => {
          // if (result.value) {
            window.location.assign("<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/'.$sub_dept_slug.'/add_admin') ?>")
            
          // }
        })
      <?php
        }
      ?>
      <?php if($this->session->add_admin){ ?>
       $.notify({
        message:"Personnel Added Successfully"
        },{
          type : "success"  
        });
      <?php }  ?>
    });
  </script>
