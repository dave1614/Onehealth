
    <?php
      if(is_array($curr_health_facility_arr)){
        foreach($curr_health_facility_arr as $row){
          $health_facility_id = $row->id;
          $health_facility_name = $row->name;
          $health_facility_logo = $row->logo;
          $health_facility_structure = $row->facility_structure;
          $health_facility_email = $row->email;
          $health_facility_phone = $row->phone;
          $health_facility_country = $row->country;
          $health_facility_state = $row->state;
          $health_facility_address = $row->address;
          $health_facility_table_name = $row->table_name;
          $health_facility_date = $row->date;
          $health_facility_time = $row->time;
          $health_facility_slug = $row->slug;
        }
      }
    ?>

    <script>
      function viewSections (elem,evt) {
        $("#main-card").hide();
        $("#dept-sections-card").show();
      }

      function goBackFromViewSectionsCard(elem,evt) {
        $("#main-card").show();
        $("#dept-sections-card").hide();
      }

      function viewSettingsCard(elem,evt){
        $("#main-card").hide();
        $("#settings-card").show();
        $("#submit-settings").show("fast");
      }

      function goBackFromSettingsCard(elem,evt){
        $("#main-card").show();
        $("#settings-card").hide();
        $("#submit-settings").hide("fast"); 
      }

      function viewEditDrugsCard(elem,evt){
        $("#main-card").hide();
        $("#manage-drugs-card").show();
      }

      function goBackFromEditDrugsStoreCard (elem,evt) {
        $("#manage-drugs-card").hide();
        $("#main-card").show();
      }
    </script>

      <!-- End Navbar -->
      <div class="spinner-overlay" style="display: none;">
        <div class="spinner-well">
          <img src="<?php echo base_url('assets/images/tests_loader.gif') ?>" alt="Loading...">
        </div>
      </div>
      <div class="content">
        <div class="container-fluid">
          <h2><?php echo $health_facility_name; ?></h2>
          <?php if($this->onehealth_model->checkIfUserIsATopAdmin($health_facility_table_name,$user_name)){ ?>
          <span style="text-transform: capitalize; font-size: 13px;" ><a class="text-info" href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/admin') ?>">Home</a>&nbsp;&nbsp; > >  &nbsp;&nbsp;<?php echo $dept_name; ?></span>
        <?php } ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="card" id="main-card">
                <div class="card-header">                  
                  <h3 class="card-title">Choose Action</h3>
                </div>

                <div class="card-body" style="margin-top: 50px;">
                  <button class="btn btn-primary" onclick="viewSections(this,event)" >View Sections</button>
                  <?php if($dept_id != 6){ ?>
                  <button class="btn btn-info" onclick="viewSettingsCard(this,event)">Edit Settings</button>
                  <?php }else{ ?>
                  <!-- <button class="btn btn-info" onclick="viewEditDrugsCard(this,event)">Manage Drugs Store</button>  -->
                  <?php } ?>
                </div>
              </div>
              
              <?php if($dept_id != 6){ ?>
              <div class="card" style="display: none;" id="settings-card">
                <div class="card-header">
                  <h3 class="card-title">Edit Settings</h3>
                  <!-- <h6>View Notifications From Users You Are following</h6> -->
                  <button class="btn btn-warning btn-round" onclick="goBackFromSettingsCard(this,event)">Go Back</button>
                </div>
                <div class="card-body">
                    <table class="table table-test dt-responsive nowrap hover display settings-table" cellspacing="0" width="100%" style="width:100%">
                      <thead style="display: none;">
                        <tr>
                          <th>Setting</th>
                          <th>CheckBox</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($dept_id == 1 || $dept_id == 3){ ?>
                        <tr>
                          <td>Print Results With Letter Heading</td>
                          <td>
                            <div class="form-check text-right">
                                <label class="form-check-label">
                                    <input class="form-check-input" name="letter_heading" id="letter_heading" <?php if($this->onehealth_model->checkIfFacilityHasLetterHeadingEnabled($health_facility_id)){ echo "checked"; } ?> type="checkbox" value="">
                                    <!-- Option one is this and that&mdash;be sure to include why it's great -->
                                    <span class="form-check-sign">
                                        <span class="check"></span>
                                    </span>
                                </label>
                            </div>
                          </td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>  
                </div>
              </div>
              <?php }else{ ?>
              <div class="card" style="display: none;" id="manage-drugs-card">
                <div class="card-header">
                  <h3 class="card-title">Manage Drugs Store </h3>
                  <!-- <h6>View Notifications From Users You Are following</h6> -->
                  <button class="btn btn-warning btn-round" onclick="goBackFromEditDrugsStoreCard(this,event)">Go Back</button>
                </div>
                <div class="card-body">

                </div>
              </div>
              <?php } ?>
              


              <div class="card" style="display: none;" id="dept-sections-card" >
                <div class="card-header">
                  
                  <h4 class="card-title" style="text-transform: capitalize;">
                    <?php echo $dept_name; ?>'s sections
                  </h4>
                  <button class="btn btn-warning btn-round" onclick="goBackFromViewSectionsCard(this,event)">Go Back</button>
                </div>

                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th class="text-center">No Of Sub-Admins</th>

                          <th class="text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $depts_arr = $this->onehealth_model->getDeptById($dept_id);
                        if(is_array($depts_arr)){
                            foreach($depts_arr as $dept){
                              $dept_name = $dept->name;
                              $dept_slug = $dept->slug;        
                            } 
                            $sub_depts = $this->onehealth_model->getSubDeptsByDeptId($dept_id); 
                            $num = 0;
                              if(is_array($sub_depts)){
                                foreach($sub_depts as $sub_dept){
                                  $sub_dept_name = $sub_dept->name;
                                  $sub_dept_slug = $sub_dept->slug;
                                  if($this->onehealth_model->getHealthFacilityTableByDeptAndPosition($health_facility_table_name,$dept_slug,$sub_dept_slug) !== false){
                                    $health_facility_table_info = $this->onehealth_model->getHealthFacilityTableByDeptAndPosition($health_facility_table_name,$dept_slug,$sub_dept_slug);
                                    if(is_array($health_facility_table_info)){
                                      foreach($health_facility_table_info as $user){
                                        $user_name = $user->user_name;
                                        $user_name_slug = url_title($user_name);
                                      }
                                      $sub_admins_num = $this->onehealth_model->getSubAdminsNum($health_facility_table_name,$dept_slug,$sub_dept_slug);
                                    }
                                  }else{
                                    $user_name = "no admin";
                                  }
                                  $num++;
                        ?>
                        <tr>
                          <td><?php echo $num; ?></td>
                          <td style="text-transform: capitalize;"><a style="color: #00bcd4;" href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/'.$sub_dept_slug.'/admin'); ?>"><?php echo $sub_dept_name; ?></a></td>
                          <?php if($user_name == "no admin"){ ?>
                          <td style="text-transform: capitalize;" class="text-center"><?php echo $user_name; ?></td>
                          <?php }else{ ?>
                            <td class="text-center" style="text-transform: capitalize;"><a class="text-blue" ><?php echo $sub_admins_num; ?></a></td>
                          <?php } ?>
                          <?php if($user_name == "no admin"){ ?>
                            <td class="td-actions text-right">
                              <a href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/'.$sub_dept_slug.'/add_admin') ?>" rel="tooltip" data-toggle="tooltip" title="Add Admin" class="btn btn-success">
                                <i class="fas fa-user-plus"></i>
                              </a>
                            </td>
                          <?php }else{ ?> 
                            <td class="td-actions text-right">
                              <a href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/'.$sub_dept_slug.'/sub_admins'); ?>" rel="tooltip" data-toggle="tooltip" title="View SubAdmins" class="btn btn-info">
                                <i class="fas fa-users"></i>
                              </a>
                                
                              <a href="<?php echo site_url('onehealth/index/'.$health_facility_slug.'/'.$dept_slug.'/'.$sub_dept_slug.'/add_admin') ?>" rel="tooltip" data-toggle="tooltip" title="Add Admin" class="btn btn-success">
                                <i class="fas fa-user-plus"></i>
                              </a> 

                             
                            </td>

                          <?php } ?> 
                        </tr>
                        <?php      
                            }
                          }
                        }
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php if($dept_id == 1 || $dept_id == 3){ ?>
          <div rel="tooltip" data-toggle="tooltip" title="Save Settings" id="submit-settings" style="cursor: pointer; position: fixed; bottom: 0; right: 0; background: #9124a3; border-radius: 50%; cursor: pointer; fill: #fff; height: 56px; outline: none; display: none; overflow: hidden; margin-bottom: 24px; margin-right: 24px; text-align: center; width: 56px; z-index: 4000;box-shadow: 0 8px 10px 1px rgba(0,0,0,0.14), 0 3px 14px 2px rgba(0,0,0,0.12), 0 5px 5px -3px rgba(0,0,0,0.2);">
            <div class="" style="display: inline-block; height: 24px; position: absolute; top: 16px; left: 16px; width: 24px;">
              <i class="fas fa-save" style="font-size: 25px; font-weight: normal; color: #fff;" aria-hidden="true"></i>
            </div>
          </div>
          <?php } ?>
        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
          <footer>&copy; <?php echo date("Y"); ?> Copyright (OneHealth Issues Global Limited). All Rights Reserved</footer>
        </div>
      </footer>
  </div>
  <!--   Core JS Files   -->
  

<script>
    $(document).ready(function() {

      $(".settings-table tbody tr").css({
        "cursor" : "pointer"
      });

      $(".settings-table tbody tr").click(function(){
        var checkBox = $(this).find('input');
        if(checkBox.is(':checked')){
          checkBox.prop('checked', false);
        }else{
         checkBox.prop('checked', true); 
        }
      });
      $("#submit-settings").click(function(event) {
        swal({
            title: 'Choose Action',
            html: "Are You Sure You Want To Proceed?",
            type: 'success',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
            cancelButtonText : "No"
        }).then(function(){
          var form_data = {};
          var checkedState = false;
          var name = '';

          $(".settings-table").each(function(index, el) {
            // console.log($(this).find('tbody tr').length)
            $(this).find('tbody tr input').each(function(index, el) {
              if($(this).is(':checked')){
                checkedState = true;
              }else{
                checkedState = false;
              }
              name = $(this).attr('name');
              form_data[name] = checkedState;
            });
          });
          
          console.log(form_data);
          var url = "<?php echo site_url('onehealth/index/' . $addition . '/' . $second_addition. '/save_settings') ?>";
          // console.log(form_data);
          $(".spinner-overlay").show();
          $.ajax({
            type : "POST",
            dataType : "json",
            responseType : "json",
            url : url,
            data : form_data,
            success : function (response) {
              console.log(response);
              $(".spinner-overlay").hide();
              if(response.success == true){
                $.notify({
                  message:"Settings Changed Successfully"
                },{
                    type : "success"  
                });
              }else{
                $.notify({
                  message:"Something Went Wrong"
                },{
                    type : "warning"  
                });
              }
            },error : function(){
              $(".spinner-overlay").hide();
              $.notify({
                message:"Something Went Wrong Check Your Internet Connection"
              },{
                  type : "danger"  
              });
            }
          }); 
        });
      });
      <?php
        // if($no_sub_admin == true){
      ?>
        // swal({
        //   title: 'Warning?',
        //   text: "You do not currently have any subadmins in this section. Dou Want To Add One?",
        //   type: 'warning',
        //   showCancelButton: true,
        //   confirmButtonColor: '#3085d6',
        //   cancelButtonColor: '#d33',
        //   confirmButtonText: 'Yes, add!'
        // }).then((result) => {
        //   // if (result.value) {
        //     console.log('dldl')
        //     window.location.assign("<?php echo site_url('onehealth/index'.$health_facility_slug.'/'.$dept_slug.'/add_sub_admin') ?>")
        //   // }
        // })
      <?php
        // }
      ?>
     
      <?php if($this->session->add_admin){ ?>
         $.notify({
          message:"Admin Added Successfully"
        },{
          type : "success"  
        });
      <?php }  ?>
    });
  </script>
