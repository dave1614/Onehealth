

<!-- Page Content -->
  
  <div id="banner-div" class="" >
    <div class="container" style="padding-top: 150px;">
      <h1 class="font-weight-light animated fadeInLeft head" style="font-weight: bolder; text-transform: uppercase; margin-bottom: 20px; color: #fff;">OneHealth&reg;</h1>
      <p class="lead animated fadeInLeft" style="color: #fff;">Offers You The Ease Of Seeking And Offering Effecient And Effective Healthcare Delivery!</p>
      <button class="btn-orange text-center" id="" onclick="signIn(this,event)">Sign Into Your Account</button>
      <!-- <p class="lead">Scroll down...</p> -->
      <!-- <div style="height: 700px"></div> -->
      
    </div>
  </div>

  


  