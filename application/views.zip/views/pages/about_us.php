  

  <div class="" style="background: #f5fbff;">
  
   
    <section id="contact" style="padding-top: 30px;">
      <div class="container">

        <h2 class="text-center sub-head" style="margin-bottom: 50px; margin-top: 20px;">About Us</h2>
        <p style="font-size: 20px; line-height: 2; text-transform: capitalize;">Onehealth Global Issues Ltd is a company with sole aim of advancing Global Health. We have special interest in developing countries and particular interest in quality of Health services. We believe that the best approach to improvement of quality of Healthcare services is to ensure maximal ease of seeking and delivering services in Healthcare sector. This can only be possible at the instance of adequate communication, documentation and records, personnel, automation of processes, accountability and realtime monitoring. These are integrated in our product Onehealth®.</p>
      </div>

    </section>
  </div>


 